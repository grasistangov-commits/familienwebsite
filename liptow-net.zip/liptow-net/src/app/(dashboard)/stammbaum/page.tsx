"use client";

import { useEffect, useMemo, useState } from "react";
import { useSession } from "next-auth/react";
import { FiPlus, FiEdit2, FiTrash2, FiX } from "react-icons/fi";
import { initialsFromName } from "@/lib/utils";

type Member = {
  id: string;
  firstName: string;
  lastName: string;
  photoUrl?: string | null;
  birthDate?: string | null;
  deathDate?: string | null;
  notes?: string | null;
  fatherId?: string | null;
  motherId?: string | null;
  partnerships: { partnerB: { id: string; firstName: string; lastName: string } }[];
  partnershipsB: { partnerA: { id: string; firstName: string; lastName: string } }[];
};

function yearsOf(m: Member) {
  const b = m.birthDate ? new Date(m.birthDate).getFullYear() : "?";
  const d = m.deathDate ? new Date(m.deathDate).getFullYear() : "";
  return d ? `${b}–${d}` : `${b}`;
}

function partnerOf(m: Member): { id: string; firstName: string; lastName: string } | null {
  if (m.partnerships[0]) return m.partnerships[0].partnerB;
  if (m.partnershipsB[0]) return m.partnershipsB[0].partnerA;
  return null;
}

export default function FamilyTreePage() {
  const { data: session } = useSession();
  const isAdmin = (session?.user as any)?.role === "ADMIN";
  const [members, setMembers] = useState<Member[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Member | null>(null);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [birthDate, setBirthDate] = useState("");
  const [deathDate, setDeathDate] = useState("");
  const [notes, setNotes] = useState("");
  const [fatherId, setFatherId] = useState("");
  const [motherId, setMotherId] = useState("");
  const [partnerId, setPartnerId] = useState("");

  async function load() {
    const res = await fetch("/api/stammbaum");
    if (res.ok) setMembers((await res.json()).members);
  }
  useEffect(() => {
    load();
  }, []);

  const byId = useMemo(() => new Map(members.map((m) => [m.id, m])), [members]);
  const consumedAsPartner = useMemo(() => {
    const set = new Set<string>();
    members.forEach((m) => {
      const p = partnerOf(m);
      // Die "jüngere" ID (später erstellt) gilt als Partner und wird nicht separat als Wurzel gerendert
      if (p && members.findIndex((x) => x.id === m.id) < members.findIndex((x) => x.id === p.id)) {
        set.add(p.id);
      }
    });
    return set;
  }, [members]);

  const roots = members.filter((m) => !m.fatherId && !m.motherId && !consumedAsPartner.has(m.id));
  const childrenOf = (id: string) => members.filter((m) => m.fatherId === id || m.motherId === id);

  function resetForm() {
    setFirstName("");
    setLastName("");
    setBirthDate("");
    setDeathDate("");
    setNotes("");
    setFatherId("");
    setMotherId("");
    setPartnerId("");
  }

  async function handleCreate() {
    if (!firstName.trim() || !lastName.trim()) return;
    await fetch("/api/stammbaum", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        firstName,
        lastName,
        birthDate: birthDate || undefined,
        deathDate: deathDate || undefined,
        notes,
        fatherId: fatherId || undefined,
        motherId: motherId || undefined,
        partnerId: partnerId || undefined,
      }),
    });
    setShowForm(false);
    resetForm();
    load();
  }

  async function handleSaveEdit() {
    if (!editing) return;
    await fetch(`/api/stammbaum/${editing.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        firstName: editing.firstName,
        lastName: editing.lastName,
        birthDate: editing.birthDate || null,
        deathDate: editing.deathDate || null,
        notes: editing.notes,
      }),
    });
    setEditing(null);
    load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Diese Person wirklich aus dem Stammbaum entfernen?")) return;
    const res = await fetch(`/api/stammbaum/${id}`, { method: "DELETE" });
    if (res.ok) load();
  }

  function PersonCard({ member }: { member: Member }) {
    const partner = partnerOf(member);
    return (
      <div className="group relative inline-flex items-stretch gap-0 rounded-xl border border-ink-900/10 dark:border-parchment-100/15 bg-white dark:bg-ink-900/70 shadow-sm">
        <div className="flex flex-col items-center gap-1 px-4 py-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-moss-600/15 text-xs font-semibold text-moss-700 dark:bg-ochre-400/15 dark:text-ochre-400">
            {initialsFromName(`${member.firstName} ${member.lastName}`)}
          </span>
          <p className="whitespace-nowrap text-sm font-medium">
            {member.firstName} {member.lastName}
          </p>
          <p className="text-[11px] text-ink-900/50 dark:text-parchment-100/50">{yearsOf(member)}</p>
          {isAdmin && (
            <div className="mt-1 hidden gap-2 group-hover:flex">
              <button onClick={() => setEditing(member)}>
                <FiEdit2 size={12} />
              </button>
              <button onClick={() => handleDelete(member.id)}>
                <FiTrash2 size={12} className="text-red-700 dark:text-red-400" />
              </button>
            </div>
          )}
        </div>
        {partner && (
          <>
            <div className="w-px self-stretch bg-ochre-500/40" />
            <div className="flex flex-col items-center gap-1 px-4 py-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-ochre-500/15 text-xs font-semibold text-ochre-600 dark:text-ochre-400">
                {initialsFromName(`${partner.firstName} ${partner.lastName}`)}
              </span>
              <p className="whitespace-nowrap text-sm font-medium">
                {partner.firstName} {partner.lastName}
              </p>
              <p className="text-[11px] text-ink-900/50 dark:text-parchment-100/50">Partner:in</p>
            </div>
          </>
        )}
      </div>
    );
  }

  function TreeNode({ member }: { member: Member }) {
    const children = childrenOf(member.id);
    const partner = partnerOf(member);
    const grandchildrenFromPartner = partner ? childrenOf(partner.id) : [];
    const allChildren = Array.from(new Set([...children, ...grandchildrenFromPartner].map((c) => c.id)))
      .map((id) => byId.get(id)!)
      .filter(Boolean);

    return (
      <li>
        <PersonCard member={member} />
        {allChildren.length > 0 && (
          <ul>
            {allChildren.map((c) => (
              <TreeNode key={c.id} member={c} />
            ))}
          </ul>
        )}
      </li>
    );
  }

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold">Stammbaum</h1>
          <p className="text-sm text-ink-900/60 dark:text-parchment-100/60">
            Die Generationen unserer Familie im Überblick.
          </p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn-primary">
          <FiPlus size={15} />
          Person hinzufügen
        </button>
      </div>

      <div className="card overflow-x-auto p-8">
        {roots.length === 0 ? (
          <p className="py-12 text-center text-sm text-ink-900/50 dark:text-parchment-100/50">
            Noch niemand im Stammbaum eingetragen.
          </p>
        ) : (
          <div className="family-tree">
            <ul>
              {roots.map((r) => (
                <TreeNode key={r.id} member={r} />
              ))}
            </ul>
          </div>
        )}
      </div>

      {(showForm || editing) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/40 p-4">
          <div className="card max-h-[85vh] w-full max-w-sm space-y-3 overflow-y-auto p-6">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">
                {editing ? "Person bearbeiten" : "Neue Person"}
              </h3>
              <button
                onClick={() => {
                  setShowForm(false);
                  setEditing(null);
                }}
              >
                <FiX size={18} />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="label">Vorname</label>
                <input
                  value={editing ? editing.firstName : firstName}
                  onChange={(e) =>
                    editing
                      ? setEditing({ ...editing, firstName: e.target.value })
                      : setFirstName(e.target.value)
                  }
                  className="input"
                />
              </div>
              <div>
                <label className="label">Nachname</label>
                <input
                  value={editing ? editing.lastName : lastName}
                  onChange={(e) =>
                    editing
                      ? setEditing({ ...editing, lastName: e.target.value })
                      : setLastName(e.target.value)
                  }
                  className="input"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="label">Geburtsdatum</label>
                <input
                  type="date"
                  value={
                    editing
                      ? editing.birthDate?.slice(0, 10) ?? ""
                      : birthDate
                  }
                  onChange={(e) =>
                    editing
                      ? setEditing({ ...editing, birthDate: e.target.value })
                      : setBirthDate(e.target.value)
                  }
                  className="input"
                />
              </div>
              <div>
                <label className="label">Sterbedatum</label>
                <input
                  type="date"
                  value={editing ? editing.deathDate?.slice(0, 10) ?? "" : deathDate}
                  onChange={(e) =>
                    editing
                      ? setEditing({ ...editing, deathDate: e.target.value })
                      : setDeathDate(e.target.value)
                  }
                  className="input"
                />
              </div>
            </div>
            {!editing && (
              <>
                <div>
                  <label className="label">Vater</label>
                  <select value={fatherId} onChange={(e) => setFatherId(e.target.value)} className="input">
                    <option value="">– keiner –</option>
                    {members.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.firstName} {m.lastName}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">Mutter</label>
                  <select value={motherId} onChange={(e) => setMotherId(e.target.value)} className="input">
                    <option value="">– keine –</option>
                    {members.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.firstName} {m.lastName}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">Partner:in</label>
                  <select value={partnerId} onChange={(e) => setPartnerId(e.target.value)} className="input">
                    <option value="">– keine/r –</option>
                    {members.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.firstName} {m.lastName}
                      </option>
                    ))}
                  </select>
                </div>
              </>
            )}
            <div>
              <label className="label">Notizen</label>
              <textarea
                value={editing ? editing.notes ?? "" : notes}
                onChange={(e) =>
                  editing ? setEditing({ ...editing, notes: e.target.value }) : setNotes(e.target.value)
                }
                className="input"
                rows={2}
              />
            </div>
            <button onClick={editing ? handleSaveEdit : handleCreate} className="btn-primary w-full">
              Speichern
            </button>
          </div>
        </div>
      )}

      <style jsx global>{`
        .family-tree ul {
          padding-top: 24px;
          position: relative;
          display: flex;
          justify-content: center;
        }
        .family-tree li {
          display: flex;
          flex-direction: column;
          align-items: center;
          list-style-type: none;
          position: relative;
          padding: 24px 12px 0 12px;
        }
        .family-tree li::before,
        .family-tree li::after {
          content: "";
          position: absolute;
          top: 0;
          border-top: 1.5px solid theme("colors.moss.500" / 35%);
          width: 50%;
          height: 24px;
        }
        .family-tree li::before {
          right: 50%;
          border-right: 1.5px solid theme("colors.moss.500" / 35%);
        }
        .family-tree li::after {
          left: 50%;
          border-left: 1.5px solid theme("colors.moss.500" / 35%);
        }
        .family-tree li:only-child::before,
        .family-tree li:only-child::after {
          display: none;
        }
        .family-tree li:only-child {
          padding-top: 0;
        }
        .family-tree li:first-child::before,
        .family-tree li:last-child::after {
          border: 0 none;
        }
        .family-tree li:last-child::before {
          border-right: 1.5px solid theme("colors.moss.500" / 35%);
          border-radius: 0 5px 0 0;
        }
        .family-tree li:first-child::after {
          border-left: 1.5px solid theme("colors.moss.500" / 35%);
          border-radius: 5px 0 0 0;
        }
        .family-tree ul ul::before {
          content: "";
          position: absolute;
          top: 0;
          left: 50%;
          border-left: 1.5px solid theme("colors.moss.500" / 35%);
          width: 0;
          height: 24px;
        }
      `}</style>
    </div>
  );
}
