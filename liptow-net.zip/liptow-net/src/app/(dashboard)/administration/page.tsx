import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { formatBytes } from "@/lib/utils";
import AdminUserTable from "@/components/AdminUserTable";
import { FiUsers, FiHardDrive, FiActivity, FiDatabase } from "react-icons/fi";

export default async function AdministrationPage() {
  const session = await getServerSession(authOptions);
  if (!session || session.user.role !== "ADMIN") redirect("/dashboard");

  const [users, totalFiles, totalMessages, totalActivity] = await Promise.all([
    prisma.user.findMany({
      orderBy: { createdAt: "asc" },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        isLocked: true,
        mustChangePassword: true,
        storageUsedBytes: true,
        storageQuotaBytes: true,
      },
    }),
    prisma.fileEntry.count(),
    prisma.message.count(),
    prisma.activityLog.count(),
  ]);

  const totalUsed = users.reduce((sum, u) => sum + u.storageUsedBytes, BigInt(0));
  const totalQuota = users.reduce((sum, u) => sum + u.storageQuotaBytes, BigInt(0));

  const serializedUsers = users.map((u) => ({
    ...u,
    storageUsedBytes: u.storageUsedBytes.toString(),
    storageQuotaBytes: u.storageQuotaBytes.toString(),
  }));

  const stats = [
    { label: "Familienmitglieder", value: users.length, icon: FiUsers },
    {
      label: "Speicher belegt",
      value: `${formatBytes(Number(totalUsed))} / ${formatBytes(Number(totalQuota))}`,
      icon: FiHardDrive,
    },
    { label: "Dateien gesamt", value: totalFiles, icon: FiDatabase },
    { label: "Chat-Nachrichten", value: totalMessages, icon: FiActivity },
  ];

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Administration</h1>
        <p className="text-sm text-ink-900/60 dark:text-parchment-100/60">
          Vollständige Verwaltung des Familienportals — {totalActivity} protokollierte
          Aktivitäten insgesamt.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="card flex items-center gap-3 p-5">
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-moss-600/10 text-moss-600 dark:bg-ochre-400/10 dark:text-ochre-400">
              <s.icon size={17} />
            </span>
            <div>
              <p className="text-lg font-semibold">{s.value}</p>
              <p className="text-xs text-ink-900/50 dark:text-parchment-100/50">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="card p-6">
        <AdminUserTable initialUsers={serializedUsers as any} />
      </div>
    </div>
  );
}
