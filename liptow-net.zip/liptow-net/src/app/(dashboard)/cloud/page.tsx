"use client";

import { useEffect, useRef, useState } from "react";
import { useSession } from "next-auth/react";
import {
  FiUpload,
  FiFolder,
  FiFolderPlus,
  FiFile,
  FiDownload,
  FiTrash2,
  FiArrowLeft,
  FiSearch,
} from "react-icons/fi";
import { formatBytes } from "@/lib/utils";

type FileItem = {
  id: string;
  name: string;
  sizeBytes: string;
  mimeType: string;
  storageKey: string;
  createdAt: string;
};
type FolderItem = { id: string; name: string };

export default function CloudPage() {
  const { data: session } = useSession();
  const isAdmin = (session?.user as any)?.role === "ADMIN";

  const [folders, setFolders] = useState<FolderItem[]>([]);
  const [files, setFiles] = useState<FileItem[]>([]);
  const [usedBytes, setUsedBytes] = useState("0");
  const [quotaBytes, setQuotaBytes] = useState("0");
  const [targetUserName, setTargetUserName] = useState("");
  const [allUsers, setAllUsers] = useState<{ id: string; name: string }[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const [folderId, setFolderId] = useState<string | null>(null);
  const [folderStack, setFolderStack] = useState<{ id: string; name: string }[]>([]);
  const [search, setSearch] = useState("");
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function load() {
    const params = new URLSearchParams();
    if (folderId) params.set("folderId", folderId);
    if (selectedUserId) params.set("userId", selectedUserId);
    const res = await fetch(`/api/cloud?${params.toString()}`);
    if (res.ok) {
      const data = await res.json();
      setFolders(data.folders);
      setFiles(data.files);
      setUsedBytes(data.usedBytes);
      setQuotaBytes(data.quotaBytes);
      setTargetUserName(data.targetUserName);
      setAllUsers(data.allUsers ?? []);
      if (!selectedUserId) setSelectedUserId(data.targetUserId);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [folderId, selectedUserId]);

  const percentUsed = quotaBytes !== "0" ? (Number(usedBytes) / Number(quotaBytes)) * 100 : 0;
  const limitReached = percentUsed >= 100;

  async function handleUpload(fileList: FileList | null) {
    if (!fileList || fileList.length === 0) return;
    setUploading(true);
    for (const file of Array.from(fileList)) {
      const form = new FormData();
      form.set("file", file);
      if (folderId) form.set("folderId", folderId);
      if (selectedUserId) form.set("userId", selectedUserId);
      const res = await fetch("/api/cloud", { method: "POST", body: form });
      if (!res.ok) {
        const err = await res.json();
        alert(err.error ?? "Upload fehlgeschlagen.");
        break;
      }
    }
    setUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = "";
    load();
  }

  async function handleCreateFolder() {
    const name = prompt("Name des neuen Ordners:");
    if (!name) return;
    await fetch("/api/cloud/folders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, parentId: folderId, userId: selectedUserId }),
    });
    load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Diese Datei wirklich löschen?")) return;
    await fetch(`/api/cloud/${id}`, { method: "DELETE" });
    load();
  }

  function openFolder(folder: FolderItem) {
    setFolderStack((s) => [...s, { id: folder.id, name: folder.name }]);
    setFolderId(folder.id);
  }

  function goBack() {
    const newStack = folderStack.slice(0, -1);
    setFolderStack(newStack);
    setFolderId(newStack.length ? newStack[newStack.length - 1].id : null);
  }

  const filteredFiles = files.filter((f) => f.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold">Familien-Cloud</h1>
          <p className="text-sm text-ink-900/60 dark:text-parchment-100/60">
            {isAdmin ? `Speicher von ${targetUserName}` : "Dein persönlicher Speicher"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {isAdmin && allUsers.length > 0 && (
            <select
              value={selectedUserId}
              onChange={(e) => {
                setSelectedUserId(e.target.value);
                setFolderId(null);
                setFolderStack([]);
              }}
              className="input !w-auto"
            >
              {allUsers.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name}
                </option>
              ))}
            </select>
          )}
          <button onClick={handleCreateFolder} className="btn-secondary">
            <FiFolderPlus size={15} />
            Ordner
          </button>
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={limitReached || uploading}
            className="btn-primary"
          >
            <FiUpload size={15} />
            {uploading ? "Lädt hoch…" : "Hochladen"}
          </button>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            onChange={(e) => handleUpload(e.target.files)}
          />
        </div>
      </div>

      <div className="card p-5">
        <div className="mb-2 flex items-center justify-between text-sm">
          <span>
            {formatBytes(Number(usedBytes))} von {formatBytes(Number(quotaBytes))} belegt
          </span>
          <span className="text-ink-900/50 dark:text-parchment-100/50">
            {formatBytes(Number(quotaBytes) - Number(usedBytes))} frei
          </span>
        </div>
        <div className="h-2 overflow-hidden rounded-full bg-ink-900/10 dark:bg-parchment-100/10">
          <div
            className={`h-full rounded-full transition-all ${
              limitReached ? "bg-red-600" : "bg-moss-600 dark:bg-ochre-400"
            }`}
            style={{ width: `${Math.min(percentUsed, 100)}%` }}
          />
        </div>
        {limitReached && (
          <p className="mt-2 text-xs text-red-700 dark:text-red-400">
            Speicherlimit erreicht – weitere Uploads sind blockiert.
          </p>
        )}
      </div>

      <div className="card p-5">
        <div className="mb-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            {folderStack.length > 0 && (
              <button onClick={goBack} className="rounded-lg p-1.5 hover:bg-ink-900/5 dark:hover:bg-parchment-100/5">
                <FiArrowLeft size={16} />
              </button>
            )}
            <span className="text-sm text-ink-900/60 dark:text-parchment-100/60">
              {folderStack.length === 0
                ? "Stammverzeichnis"
                : folderStack.map((f) => f.name).join(" / ")}
            </span>
          </div>
          <div className="relative w-52">
            <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-900/40" size={14} />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Dateien suchen…"
              className="input !pl-8"
            />
          </div>
        </div>

        {folders.length === 0 && filteredFiles.length === 0 ? (
          <p className="py-8 text-center text-sm text-ink-900/50 dark:text-parchment-100/50">
            Dieser Ordner ist leer.
          </p>
        ) : (
          <div className="divide-y divide-ink-900/5 dark:divide-parchment-100/10">
            {folders.map((f) => (
              <button
                key={f.id}
                onClick={() => openFolder(f)}
                className="flex w-full items-center gap-3 py-3 text-left text-sm hover:bg-ink-900/[0.02] dark:hover:bg-parchment-100/[0.02]"
              >
                <FiFolder className="text-moss-600 dark:text-ochre-400" size={18} />
                {f.name}
              </button>
            ))}
            {filteredFiles.map((f) => (
              <div key={f.id} className="flex items-center gap-3 py-3 text-sm">
                <FiFile className="text-ink-900/40 dark:text-parchment-100/40" size={18} />
                <span className="flex-1 truncate">{f.name}</span>
                <span className="text-xs text-ink-900/40 dark:text-parchment-100/40">
                  {formatBytes(Number(f.sizeBytes))}
                </span>
                <a
                  href={`/api/files/${encodeURIComponent(f.storageKey)}`}
                  target="_blank"
                  className="rounded-lg p-1.5 hover:bg-ink-900/5 dark:hover:bg-parchment-100/5"
                >
                  <FiDownload size={15} />
                </a>
                <button
                  onClick={() => handleDelete(f.id)}
                  className="rounded-lg p-1.5 hover:bg-red-700/10"
                >
                  <FiTrash2 size={15} className="text-red-700 dark:text-red-400" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
