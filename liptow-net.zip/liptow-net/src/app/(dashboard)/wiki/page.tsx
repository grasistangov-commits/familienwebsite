"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { FiPlus, FiBookOpen, FiX } from "react-icons/fi";

type WikiPageItem = {
  id: string;
  title: string;
  category: string;
  updatedAt: string;
  author: { name: string };
};

export default function WikiPage() {
  const router = useRouter();
  const [pages, setPages] = useState<WikiPageItem[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("Allgemein");

  async function load() {
    const res = await fetch("/api/wiki");
    if (res.ok) setPages((await res.json()).pages);
  }
  useEffect(() => {
    load();
  }, []);

  const grouped = useMemo(() => {
    const map = new Map<string, WikiPageItem[]>();
    pages.forEach((p) => {
      const list = map.get(p.category) ?? [];
      list.push(p);
      map.set(p.category, list);
    });
    return map;
  }, [pages]);

  async function handleCreate() {
    if (!title.trim()) return;
    const res = await fetch("/api/wiki", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, category, content: "" }),
    });
    if (res.ok) {
      const { page } = await res.json();
      router.push(`/wiki/${page.id}`);
    }
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold">Familienwiki</h1>
          <p className="text-sm text-ink-900/60 dark:text-parchment-100/60">
            Familiengeschichte, Rezepte, Erinnerungen und wichtige Informationen.
          </p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn-primary">
          <FiPlus size={15} />
          Neue Seite
        </button>
      </div>

      {pages.length === 0 ? (
        <p className="py-12 text-center text-sm text-ink-900/50 dark:text-parchment-100/50">
          Noch keine Wiki-Seiten vorhanden.
        </p>
      ) : (
        <div className="space-y-6">
          {Array.from(grouped.entries()).map(([cat, items]) => (
            <div key={cat} className="card p-5">
              <h2 className="mb-3 font-display text-base font-semibold text-moss-600 dark:text-ochre-400">
                {cat}
              </h2>
              <ul className="divide-y divide-ink-900/5 dark:divide-parchment-100/10">
                {items.map((p) => (
                  <li key={p.id}>
                    <Link
                      href={`/wiki/${p.id}`}
                      className="flex items-center justify-between py-2.5 text-sm hover:text-moss-600 dark:hover:text-ochre-400"
                    >
                      <span className="flex items-center gap-2">
                        <FiBookOpen size={14} className="opacity-50" />
                        {p.title}
                      </span>
                      <span className="text-xs text-ink-900/40 dark:text-parchment-100/40">
                        {p.author.name} · {new Date(p.updatedAt).toLocaleDateString("de-DE")}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/40 p-4">
          <div className="card w-full max-w-sm space-y-3 p-6">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">Neue Wiki-Seite</h3>
              <button onClick={() => setShowForm(false)}>
                <FiX size={18} />
              </button>
            </div>
            <div>
              <label className="label">Titel</label>
              <input value={title} onChange={(e) => setTitle(e.target.value)} className="input" />
            </div>
            <div>
              <label className="label">Kategorie</label>
              <input value={category} onChange={(e) => setCategory(e.target.value)} className="input" />
            </div>
            <button onClick={handleCreate} className="btn-primary w-full">
              Erstellen &amp; bearbeiten
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
