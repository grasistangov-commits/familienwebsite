"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { FiArrowLeft, FiSave, FiTrash2, FiEdit2 } from "react-icons/fi";

type WikiPageDetail = {
  id: string;
  title: string;
  content: string;
  category: string;
  updatedAt: string;
  author: { name: string };
};

export default function WikiDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [page, setPage] = useState<WikiPageDetail | null>(null);
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("");
  const [content, setContent] = useState("");

  async function load() {
    const res = await fetch(`/api/wiki/${id}`);
    if (res.ok) {
      const { page } = await res.json();
      setPage(page);
      setTitle(page.title);
      setCategory(page.category);
      setContent(page.content);
    }
  }
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function handleSave() {
    await fetch(`/api/wiki/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, category, content }),
    });
    setEditing(false);
    load();
  }

  async function handleDelete() {
    if (!confirm("Diese Wiki-Seite wirklich löschen?")) return;
    await fetch(`/api/wiki/${id}`, { method: "DELETE" });
    router.push("/wiki");
  }

  if (!page) return null;

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link href="/wiki" className="rounded-lg p-1.5 hover:bg-ink-900/5 dark:hover:bg-parchment-100/5">
            <FiArrowLeft size={18} />
          </Link>
          <span className="rounded-full bg-moss-600/10 px-2.5 py-0.5 text-xs text-moss-700 dark:bg-ochre-400/10 dark:text-ochre-400">
            {page.category}
          </span>
        </div>
        <div className="flex gap-2">
          {editing ? (
            <button onClick={handleSave} className="btn-primary">
              <FiSave size={15} />
              Speichern
            </button>
          ) : (
            <button onClick={() => setEditing(true)} className="btn-secondary">
              <FiEdit2 size={15} />
              Bearbeiten
            </button>
          )}
          <button onClick={handleDelete} className="btn-secondary !text-red-700 dark:!text-red-400">
            <FiTrash2 size={15} />
          </button>
        </div>
      </div>

      <div className="card p-7">
        {editing ? (
          <div className="space-y-3">
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="input font-display text-xl font-semibold"
            />
            <input value={category} onChange={(e) => setCategory(e.target.value)} className="input" />
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="input min-h-[320px] font-mono text-sm"
            />
          </div>
        ) : (
          <>
            <h1 className="font-display text-2xl font-semibold">{page.title}</h1>
            <p className="mt-1 text-xs text-ink-900/40 dark:text-parchment-100/40">
              von {page.author.name} · zuletzt bearbeitet am{" "}
              {new Date(page.updatedAt).toLocaleDateString("de-DE")}
            </p>
            <div className="prose prose-sm dark:prose-invert mt-5 max-w-none whitespace-pre-wrap">
              {page.content || (
                <span className="text-ink-900/40 dark:text-parchment-100/40">
                  Diese Seite hat noch keinen Inhalt.
                </span>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
