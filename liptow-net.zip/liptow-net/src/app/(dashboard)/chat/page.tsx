"use client";

import { useEffect, useRef, useState, FormEvent } from "react";
import { useSession } from "next-auth/react";
import { FiSend, FiPaperclip, FiEdit2, FiTrash2, FiCornerUpLeft, FiX } from "react-icons/fi";
import { initialsFromName } from "@/lib/utils";

type ChatMessage = {
  id: string;
  content: string;
  imageUrl?: string | null;
  videoUrl?: string | null;
  fileUrl?: string | null;
  editedAt?: string | null;
  deletedAt?: string | null;
  createdAt: string;
  sender: { id: string; name: string; avatarUrl?: string | null };
  replyTo?: { sender: { name: string }; content: string } | null;
};

export default function ChatPage() {
  const { data: session } = useSession();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [text, setText] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [replyTo, setReplyTo] = useState<ChatMessage | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function load() {
    const res = await fetch("/api/chat");
    if (res.ok) {
      const data = await res.json();
      setMessages(data.messages);
    }
  }

  useEffect(() => {
    load();
    const interval = setInterval(load, 4000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  async function handleSend(e: FormEvent) {
    e.preventDefault();
    if (!text.trim() && !file) return;

    const form = new FormData();
    form.set("content", text);
    if (replyTo) form.set("replyToId", replyTo.id);
    if (file) form.set("file", file);

    setText("");
    setFile(null);
    setReplyTo(null);
    if (fileInputRef.current) fileInputRef.current.value = "";

    const res = await fetch("/api/chat", { method: "POST", body: form });
    if (res.ok) load();
  }

  async function handleEditSave(id: string) {
    const res = await fetch(`/api/chat/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content: editText }),
    });
    if (res.ok) {
      setEditingId(null);
      load();
    }
  }

  async function handleDelete(id: string) {
    if (!confirm("Diese Nachricht wirklich löschen?")) return;
    const res = await fetch(`/api/chat/${id}`, { method: "DELETE" });
    if (res.ok) load();
  }

  return (
    <div className="mx-auto flex h-[calc(100vh-8rem)] max-w-3xl flex-col">
      <h1 className="mb-4 font-display text-2xl font-semibold">Familienchat</h1>

      <div className="card flex flex-1 flex-col overflow-hidden">
        <div className="flex-1 space-y-4 overflow-y-auto p-5 scrollbar-thin">
          {messages.map((m) => {
            const mine = m.sender.id === (session?.user as any)?.id;
            const isAdmin = (session?.user as any)?.role === "ADMIN";
            return (
              <div key={m.id} className={`flex gap-2.5 ${mine ? "flex-row-reverse" : ""}`}>
                <span className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-moss-600/15 text-xs font-semibold text-moss-700 dark:bg-ochre-400/15 dark:text-ochre-400">
                  {initialsFromName(m.sender.name)}
                </span>
                <div className={`max-w-[75%] ${mine ? "items-end" : "items-start"} flex flex-col`}>
                  <div
                    className={`rounded-2xl px-4 py-2.5 text-sm ${
                      mine
                        ? "bg-moss-600 text-parchment-50"
                        : "bg-ink-900/5 dark:bg-parchment-100/10"
                    }`}
                  >
                    {!mine && (
                      <p className="mb-0.5 text-xs font-semibold opacity-70">{m.sender.name}</p>
                    )}
                    {m.replyTo && (
                      <p className="mb-1 truncate border-l-2 border-current/30 pl-2 text-xs opacity-70">
                        {m.replyTo.sender.name}: {m.replyTo.content}
                      </p>
                    )}
                    {m.deletedAt ? (
                      <p className="italic opacity-60">Nachricht wurde gelöscht</p>
                    ) : editingId === m.id ? (
                      <div className="flex items-center gap-2">
                        <input
                          value={editText}
                          onChange={(e) => setEditText(e.target.value)}
                          className="rounded-lg border border-current/20 bg-transparent px-2 py-1 text-sm outline-none"
                          autoFocus
                        />
                        <button onClick={() => handleEditSave(m.id)} className="text-xs underline">
                          Speichern
                        </button>
                      </div>
                    ) : (
                      <>
                        {m.content && <p className="whitespace-pre-wrap">{m.content}</p>}
                        {m.imageUrl && (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            src={m.imageUrl}
                            alt="Angehängtes Bild"
                            className="mt-2 max-h-64 rounded-lg object-cover"
                          />
                        )}
                        {m.videoUrl && (
                          <video src={m.videoUrl} controls className="mt-2 max-h-64 rounded-lg" />
                        )}
                        {m.fileUrl && (
                          <a href={m.fileUrl} className="mt-2 block underline" target="_blank">
                            Anhang öffnen
                          </a>
                        )}
                      </>
                    )}
                  </div>
                  {!m.deletedAt && (
                    <div className="mt-1 flex items-center gap-2 text-[11px] text-ink-900/40 dark:text-parchment-100/40">
                      <span>
                        {new Date(m.createdAt).toLocaleTimeString("de-DE", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                        {m.editedAt && " · bearbeitet"}
                      </span>
                      <button onClick={() => setReplyTo(m)} className="hover:underline">
                        <FiCornerUpLeft size={11} />
                      </button>
                      {(mine || isAdmin) && (
                        <>
                          <button
                            onClick={() => {
                              setEditingId(m.id);
                              setEditText(m.content);
                            }}
                            className="hover:underline"
                          >
                            <FiEdit2 size={11} />
                          </button>
                          <button onClick={() => handleDelete(m.id)} className="hover:underline">
                            <FiTrash2 size={11} />
                          </button>
                        </>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          <div ref={bottomRef} />
        </div>

        <div className="border-t border-ink-900/5 dark:border-parchment-100/10 p-3">
          {replyTo && (
            <div className="mb-2 flex items-center justify-between rounded-lg bg-ink-900/5 dark:bg-parchment-100/5 px-3 py-1.5 text-xs">
              <span className="truncate">
                Antwort an <strong>{replyTo.sender.name}</strong>: {replyTo.content}
              </span>
              <button onClick={() => setReplyTo(null)}>
                <FiX size={13} />
              </button>
            </div>
          )}
          {file && (
            <div className="mb-2 flex items-center justify-between rounded-lg bg-ink-900/5 dark:bg-parchment-100/5 px-3 py-1.5 text-xs">
              <span className="truncate">{file.name}</span>
              <button onClick={() => setFile(null)}>
                <FiX size={13} />
              </button>
            </div>
          )}
          <form onSubmit={handleSend} className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-ink-900/60 dark:text-parchment-100/60 hover:bg-ink-900/5 dark:hover:bg-parchment-100/5"
            >
              <FiPaperclip size={18} />
            </button>
            <input
              ref={fileInputRef}
              type="file"
              className="hidden"
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            />
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Nachricht schreiben…"
              className="input flex-1"
            />
            <button type="submit" className="btn-primary shrink-0 !px-3.5">
              <FiSend size={16} />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
