import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import DashboardShell from "@/components/DashboardShell";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");

  return (
    <DashboardShell
      name={session.user.name}
      avatarUrl={session.user.avatarUrl}
      isAdmin={session.user.role === "ADMIN"}
    >
      {children}
    </DashboardShell>
  );
}
