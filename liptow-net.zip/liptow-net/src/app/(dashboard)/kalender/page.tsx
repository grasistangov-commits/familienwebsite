"use client";

import { useEffect, useMemo, useState } from "react";
import { FiChevronLeft, FiChevronRight, FiPlus, FiTrash2, FiBell } from "react-icons/fi";

type EventItem = {
  id: string;
  title: string;
  description?: string | null;
  startsAt: string;
  endsAt: string;
  allDay: boolean;
  reminder: boolean;
  createdBy: { name: string };
};

const WEEKDAYS = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
const MONTHS = [
  "Januar","Februar","März","April","Mai","Juni",
  "Juli","August","September","Oktober","November","Dezember",
];

export default function CalendarPage() {
  const [events, setEvents] = useState<EventItem[]>([]);
  const [cursor, setCursor] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [reminder, setReminder] = useState(false);

  async function load() {
    const res = await fetch("/api/kalender");
    if (res.ok) setEvents((await res.json()).events);
  }
  useEffect(() => {
    load();
  }, []);

  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const firstDay = new Date(year, month, 1);
  const startOffset = (firstDay.getDay() + 6) % 7; // Montag = 0
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const cells = useMemo(() => {
    const arr: (Date | null)[] = [];
    for (let i = 0; i < startOffset; i++) arr.push(null);
    for (let d = 1; d <= daysInMonth; d++) arr.push(new Date(year, month, d));
    return arr;
  }, [year, month, startOffset, daysInMonth]);

  function eventsOn(date: Date) {
    return events.filter((e) => {
      const s = new Date(e.startsAt);
      return (
        s.getFullYear() === date.getFullYear() &&
        s.getMonth() === date.getMonth() &&
        s.getDate() === date.getDate()
      );
    });
  }

  async function handleCreate() {
    if (!title.trim() || !start || !end) return;
    await fetch("/api/kalender", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, description, startsAt: start, endsAt: end, reminder }),
    });
    setShowForm(false);
    setTitle("");
    setDescription("");
    setStart("");
    setEnd("");
    setReminder(false);
    load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Termin wirklich löschen?")) return;
    await fetch(`/api/kalender/${id}`, { method: "DELETE" });
    load();
  }

  const upcoming = events
    .filter((e) => new Date(e.startsAt) >= new Date())
    .sort((a, b) => new Date(a.startsAt).getTime() - new Date(b.startsAt).getTime())
    .slice(0, 6);

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-semibold">Familienkalender</h1>
        <button
          onClick={() => {
            const d = selectedDate ?? new Date();
            const iso = d.toISOString().slice(0, 16);
            setStart(iso);
            setEnd(iso);
            setShowForm(true);
          }}
          className="btn-primary"
        >
          <FiPlus size={15} />
          Termin
        </button>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="card p-5 lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <button
              onClick={() => setCursor(new Date(year, month - 1, 1))}
              className="rounded-lg p-1.5 hover:bg-ink-900/5 dark:hover:bg-parchment-100/5"
            >
              <FiChevronLeft size={18} />
            </button>
            <h2 className="font-display text-lg font-semibold">
              {MONTHS[month]} {year}
            </h2>
            <button
              onClick={() => setCursor(new Date(year, month + 1, 1))}
              className="rounded-lg p-1.5 hover:bg-ink-900/5 dark:hover:bg-parchment-100/5"
            >
              <FiChevronRight size={18} />
            </button>
          </div>
          <div className="grid grid-cols-7 gap-1 text-center text-xs text-ink-900/50 dark:text-parchment-100/50">
            {WEEKDAYS.map((w) => (
              <div key={w} className="pb-2 font-medium">
                {w}
              </div>
            ))}
            {cells.map((date, i) => {
              const dayEvents = date ? eventsOn(date) : [];
              const isToday = date && date.toDateString() === new Date().toDateString();
              return (
                <button
                  key={i}
                  disabled={!date}
                  onClick={() => date && setSelectedDate(date)}
                  className={`flex aspect-square flex-col items-center justify-start rounded-lg p-1 text-sm transition ${
                    date ? "hover:bg-ink-900/5 dark:hover:bg-parchment-100/5" : ""
                  } ${
                    selectedDate?.toDateString() === date?.toDateString()
                      ? "bg-moss-600 text-parchment-50"
                      : isToday
                      ? "font-semibold text-moss-600 dark:text-ochre-400"
                      : ""
                  }`}
                >
                  {date?.getDate()}
                  {dayEvents.length > 0 && (
                    <span className="mt-0.5 h-1 w-1 rounded-full bg-current" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-4">
          <div className="card p-5">
            <h3 className="mb-3 font-display text-base font-semibold">
              {selectedDate ? selectedDate.toLocaleDateString("de-DE") : "Nächste Termine"}
            </h3>
            {(selectedDate ? eventsOn(selectedDate) : upcoming).length === 0 ? (
              <p className="text-sm text-ink-900/50 dark:text-parchment-100/50">
                Keine Termine.
              </p>
            ) : (
              <ul className="space-y-3">
                {(selectedDate ? eventsOn(selectedDate) : upcoming).map((e) => (
                  <li key={e.id} className="flex items-start justify-between gap-2 text-sm">
                    <div>
                      <p className="font-medium">
                        {e.reminder && <FiBell className="mr-1 inline" size={12} />}
                        {e.title}
                      </p>
                      <p className="text-xs text-ink-900/50 dark:text-parchment-100/50">
                        {new Date(e.startsAt).toLocaleString("de-DE")}
                      </p>
                      {e.description && (
                        <p className="mt-1 text-xs text-ink-900/60 dark:text-parchment-100/60">
                          {e.description}
                        </p>
                      )}
                    </div>
                    <button onClick={() => handleDelete(e.id)}>
                      <FiTrash2 size={13} className="text-red-700 dark:text-red-400" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/40 p-4">
          <div className="card w-full max-w-sm space-y-3 p-6">
            <h3 className="font-display text-lg font-semibold">Neuer Termin</h3>
            <div>
              <label className="label">Titel</label>
              <input value={title} onChange={(e) => setTitle(e.target.value)} className="input" />
            </div>
            <div>
              <label className="label">Beschreibung</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="input"
                rows={2}
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="label">Start</label>
                <input
                  type="datetime-local"
                  value={start}
                  onChange={(e) => setStart(e.target.value)}
                  className="input"
                />
              </div>
              <div>
                <label className="label">Ende</label>
                <input
                  type="datetime-local"
                  value={end}
                  onChange={(e) => setEnd(e.target.value)}
                  className="input"
                />
              </div>
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={reminder}
                onChange={(e) => setReminder(e.target.checked)}
              />
              Erinnerung setzen
            </label>
            <div className="flex gap-2 pt-2">
              <button onClick={() => setShowForm(false)} className="btn-secondary flex-1">
                Abbrechen
              </button>
              <button onClick={handleCreate} className="btn-primary flex-1">
                Speichern
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
