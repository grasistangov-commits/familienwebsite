"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { FiPlus, FiImage, FiX } from "react-icons/fi";

type AlbumItem = {
  id: string;
  title: string;
  description?: string | null;
  coverUrl?: string | null;
  createdBy: { name: string };
  _count: { photos: number };
};

export default function GalleryPage() {
  const [albums, setAlbums] = useState<AlbumItem[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");

  async function load() {
    const res = await fetch("/api/gallery/albums");
    if (res.ok) setAlbums((await res.json()).albums);
  }
  useEffect(() => {
    load();
  }, []);

  async function handleCreate() {
    if (!title.trim()) return;
    await fetch("/api/gallery/albums", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, description }),
    });
    setShowForm(false);
    setTitle("");
    setDescription("");
    load();
  }

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold">Fotogalerie</h1>
          <p className="text-sm text-ink-900/60 dark:text-parchment-100/60">
            Urlaube, Geburtstage, Weihnachten und Familienfeiern an einem Ort.
          </p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn-primary">
          <FiPlus size={15} />
          Album
        </button>
      </div>

      {albums.length === 0 ? (
        <p className="py-12 text-center text-sm text-ink-900/50 dark:text-parchment-100/50">
          Noch keine Alben vorhanden. Lege das erste Album an.
        </p>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {albums.map((a) => (
            <Link
              key={a.id}
              href={`/gallery/${a.id}`}
              className="card group overflow-hidden transition hover:-translate-y-0.5 hover:shadow-md"
            >
              <div className="flex h-40 items-center justify-center bg-ink-900/5 dark:bg-parchment-100/5">
                {a.coverUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={a.coverUrl} alt={a.title} className="h-full w-full object-cover" />
                ) : (
                  <FiImage size={28} className="text-ink-900/20 dark:text-parchment-100/20" />
                )}
              </div>
              <div className="p-4">
                <h3 className="font-display text-base font-semibold">{a.title}</h3>
                <p className="mt-0.5 text-xs text-ink-900/50 dark:text-parchment-100/50">
                  {a._count.photos} Fotos · von {a.createdBy.name}
                </p>
              </div>
            </Link>
          ))}
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/40 p-4">
          <div className="card w-full max-w-sm space-y-3 p-6">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">Neues Album</h3>
              <button onClick={() => setShowForm(false)}>
                <FiX size={18} />
              </button>
            </div>
            <div>
              <label className="label">Titel</label>
              <input value={title} onChange={(e) => setTitle(e.target.value)} className="input" />
            </div>
            <div>
              <label className="label">Beschreibung</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="input"
                rows={2}
              />
            </div>
            <button onClick={handleCreate} className="btn-primary w-full">
              Album anlegen
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
