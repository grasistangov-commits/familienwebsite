"use client";

import { useEffect, useRef, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import Link from "next/link";
import { FiArrowLeft, FiUpload, FiTrash2, FiX, FiSend } from "react-icons/fi";

type Comment = { id: string; content: string; author: { name: string } };
type Photo = {
  id: string;
  url: string;
  type: string;
  caption?: string | null;
  uploadedBy: { name: string };
  comments: Comment[];
};
type AlbumDetail = {
  id: string;
  title: string;
  description?: string | null;
  createdById: string;
  createdBy: { name: string };
  photos: Photo[];
};

export default function AlbumDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { data: session } = useSession();
  const [album, setAlbum] = useState<AlbumDetail | null>(null);
  const [uploading, setUploading] = useState(false);
  const [activePhoto, setActivePhoto] = useState<Photo | null>(null);
  const [commentText, setCommentText] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function load() {
    const res = await fetch(`/api/gallery/albums/${id}`);
    if (res.ok) setAlbum((await res.json()).album);
  }
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function handleUpload(fileList: FileList | null) {
    if (!fileList || fileList.length === 0) return;
    setUploading(true);
    const form = new FormData();
    Array.from(fileList).forEach((f) => form.append("files", f));
    await fetch(`/api/gallery/albums/${id}/photos`, { method: "POST", body: form });
    setUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = "";
    load();
  }

  async function handleDeletePhoto(photoId: string) {
    if (!confirm("Dieses Foto wirklich löschen?")) return;
    await fetch(`/api/gallery/photos/${photoId}`, { method: "DELETE" });
    setActivePhoto(null);
    load();
  }

  async function handleDeleteAlbum() {
    if (!confirm("Das gesamte Album inklusive aller Fotos löschen?")) return;
    await fetch(`/api/gallery/albums/${id}`, { method: "DELETE" });
    router.push("/gallery");
  }

  async function handleComment() {
    if (!activePhoto || !commentText.trim()) return;
    const res = await fetch(`/api/gallery/photos/${activePhoto.id}/comments`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content: commentText }),
    });
    if (res.ok) {
      const { comment } = await res.json();
      setActivePhoto({ ...activePhoto, comments: [...activePhoto.comments, comment] });
      setCommentText("");
      load();
    }
  }

  if (!album) return null;

  const isAdmin = (session?.user as any)?.role === "ADMIN";
  const canDeleteAlbum = isAdmin || album.createdById === (session?.user as any)?.id;

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link href="/gallery" className="rounded-lg p-1.5 hover:bg-ink-900/5 dark:hover:bg-parchment-100/5">
            <FiArrowLeft size={18} />
          </Link>
          <div>
            <h1 className="font-display text-2xl font-semibold">{album.title}</h1>
            {album.description && (
              <p className="text-sm text-ink-900/60 dark:text-parchment-100/60">
                {album.description}
              </p>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {canDeleteAlbum && (
            <button onClick={handleDeleteAlbum} className="btn-secondary !text-red-700 dark:!text-red-400">
              <FiTrash2 size={15} />
              Album löschen
            </button>
          )}
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="btn-primary"
          >
            <FiUpload size={15} />
            {uploading ? "Lädt hoch…" : "Fotos hinzufügen"}
          </button>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="image/*,video/*"
            className="hidden"
            onChange={(e) => handleUpload(e.target.files)}
          />
        </div>
      </div>

      {album.photos.length === 0 ? (
        <p className="py-12 text-center text-sm text-ink-900/50 dark:text-parchment-100/50">
          Noch keine Fotos in diesem Album.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {album.photos.map((p) => (
            <button
              key={p.id}
              onClick={() => setActivePhoto(p)}
              className="group aspect-square overflow-hidden rounded-xl bg-ink-900/5 dark:bg-parchment-100/5"
            >
              {p.type === "video" ? (
                <video src={p.url} className="h-full w-full object-cover" />
              ) : (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={p.url}
                  alt={p.caption ?? "Familienfoto"}
                  className="h-full w-full object-cover transition group-hover:scale-105"
                />
              )}
            </button>
          ))}
        </div>
      )}

      {activePhoto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/70 p-4">
          <div className="card flex max-h-[90vh] w-full max-w-3xl flex-col overflow-hidden md:flex-row">
            <div className="flex flex-1 items-center justify-center bg-ink-950">
              {activePhoto.type === "video" ? (
                <video src={activePhoto.url} controls className="max-h-[70vh] w-full" />
              ) : (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={activePhoto.url}
                  alt={activePhoto.caption ?? "Familienfoto"}
                  className="max-h-[70vh] w-full object-contain"
                />
              )}
            </div>
            <div className="flex w-full flex-col md:w-72">
              <div className="flex items-center justify-between border-b border-ink-900/5 dark:border-parchment-100/10 p-4">
                <p className="text-sm text-ink-900/60 dark:text-parchment-100/60">
                  von {activePhoto.uploadedBy.name}
                </p>
                <div className="flex items-center gap-2">
                  <button onClick={() => handleDeletePhoto(activePhoto.id)}>
                    <FiTrash2 size={15} className="text-red-700 dark:text-red-400" />
                  </button>
                  <button onClick={() => setActivePhoto(null)}>
                    <FiX size={18} />
                  </button>
                </div>
              </div>
              <div className="flex-1 space-y-3 overflow-y-auto p-4 scrollbar-thin">
                {activePhoto.comments.length === 0 ? (
                  <p className="text-xs text-ink-900/40 dark:text-parchment-100/40">
                    Noch keine Kommentare.
                  </p>
                ) : (
                  activePhoto.comments.map((c) => (
                    <div key={c.id} className="text-sm">
                      <p className="font-medium">{c.author.name}</p>
                      <p className="text-ink-900/70 dark:text-parchment-100/70">{c.content}</p>
                    </div>
                  ))
                )}
              </div>
              <div className="flex items-center gap-2 border-t border-ink-900/5 dark:border-parchment-100/10 p-3">
                <input
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Kommentar schreiben…"
                  className="input flex-1"
                  onKeyDown={(e) => e.key === "Enter" && handleComment()}
                />
                <button onClick={handleComment} className="btn-primary !px-3">
                  <FiSend size={15} />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
