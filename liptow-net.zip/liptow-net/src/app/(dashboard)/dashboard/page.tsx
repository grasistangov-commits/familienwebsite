import { getServerSession } from "next-auth";
import Link from "next/link";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { formatBytes } from "@/lib/utils";
import {
  FiMessageCircle,
  FiHardDrive,
  FiImage,
  FiCalendar,
  FiGitBranch,
  FiCheckSquare,
} from "react-icons/fi";

const QUICK_LINKS = [
  { href: "/chat", label: "Familienchat", icon: FiMessageCircle },
  { href: "/cloud", label: "Familien-Cloud", icon: FiHardDrive },
  { href: "/gallery", label: "Fotogalerie", icon: FiImage },
  { href: "/kalender", label: "Kalender", icon: FiCalendar },
  { href: "/stammbaum", label: "Stammbaum", icon: FiGitBranch },
  { href: "/aufgaben", label: "Aufgaben", icon: FiCheckSquare },
];

function daysUntilNextBirthday(birthDate: Date): number {
  const now = new Date();
  const next = new Date(now.getFullYear(), birthDate.getMonth(), birthDate.getDate());
  if (next < now) next.setFullYear(now.getFullYear() + 1);
  return Math.ceil((next.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
}

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  const userId = session!.user.id;

  const [user, upcomingEvents, recentActivity, usersWithBirthdays, unreadMessageCount] =
    await Promise.all([
      prisma.user.findUnique({ where: { id: userId } }),
      prisma.calendarEvent.findMany({
        where: { startsAt: { gte: new Date() } },
        orderBy: { startsAt: "asc" },
        take: 4,
      }),
      prisma.activityLog.findMany({
        orderBy: { createdAt: "desc" },
        take: 6,
        include: { user: { select: { name: true } } },
      }),
      prisma.user.findMany({
        where: { birthDate: { not: null } },
        select: { name: true, birthDate: true },
      }),
      prisma.message.count({
        where: { createdAt: { gte: new Date(Date.now() - 1000 * 60 * 60 * 24) } },
      }),
    ]);

  const birthdays = usersWithBirthdays
    .filter((u) => u.birthDate)
    .map((u) => ({ name: u.name, days: daysUntilNextBirthday(u.birthDate as Date) }))
    .sort((a, b) => a.days - b.days)
    .slice(0, 4);

  const hour = new Date().getHours();
  const greeting = hour < 11 ? "Guten Morgen" : hour < 18 ? "Schönen Tag" : "Guten Abend";

  return (
    <div className="mx-auto max-w-6xl space-y-8">
      <div className="animate-fade-up">
        <p className="font-display italic text-moss-600 dark:text-ochre-400">{greeting},</p>
        <h1 className="font-display text-3xl font-semibold sm:text-4xl">{user?.name}</h1>
        <p className="mt-2 text-sm text-ink-900/60 dark:text-parchment-100/60">
          Schön, dass du wieder da bist. Hier ist, was sich in der Familie tut.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {QUICK_LINKS.map(({ href, label, icon: Icon }) => (
          <Link
            key={href}
            href={href}
            className="card group flex flex-col items-center gap-2 p-4 text-center transition hover:-translate-y-0.5 hover:shadow-md"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-moss-600/10 text-moss-600 dark:bg-ochre-400/10 dark:text-ochre-400 transition group-hover:bg-moss-600 group-hover:text-parchment-50">
              <Icon size={17} />
            </span>
            <span className="text-xs font-medium">{label}</span>
          </Link>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="card p-6 lg:col-span-2">
          <h2 className="mb-4 font-display text-lg font-semibold">Letzte Aktivitäten</h2>
          {recentActivity.length === 0 ? (
            <p className="text-sm text-ink-900/50 dark:text-parchment-100/50">
              Noch keine Aktivitäten vorhanden.
            </p>
          ) : (
            <ul className="space-y-4">
              {recentActivity.map((a) => (
                <li key={a.id} className="flex gap-3 text-sm">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-moss-500 dark:bg-ochre-400" />
                  <div>
                    <p>
                      <span className="font-medium">{a.user.name}</span>{" "}
                      <span className="text-ink-900/60 dark:text-parchment-100/60">
                        {a.detail ?? a.action}
                      </span>
                    </p>
                    <p className="text-xs text-ink-900/40 dark:text-parchment-100/40">
                      {new Date(a.createdAt).toLocaleString("de-DE")}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          )}
          <p className="mt-4 text-xs text-ink-900/40 dark:text-parchment-100/40">
            {unreadMessageCount} Nachrichten im Familienchat in den letzten 24 Stunden.
          </p>
        </div>

        <div className="space-y-6">
          <div className="card p-6">
            <h2 className="mb-4 font-display text-lg font-semibold">Geburtstage</h2>
            {birthdays.length === 0 ? (
              <p className="text-sm text-ink-900/50 dark:text-parchment-100/50">
                Noch keine Geburtstage hinterlegt.
              </p>
            ) : (
              <ul className="space-y-3">
                {birthdays.map((b) => (
                  <li key={b.name} className="flex items-center justify-between text-sm">
                    <span>{b.name}</span>
                    <span className="text-xs text-moss-600 dark:text-ochre-400">
                      {b.days === 0 ? "Heute!" : `in ${b.days} Tagen`}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="card p-6">
            <h2 className="mb-4 font-display text-lg font-semibold">Nächste Termine</h2>
            {upcomingEvents.length === 0 ? (
              <p className="text-sm text-ink-900/50 dark:text-parchment-100/50">
                Keine anstehenden Termine.
              </p>
            ) : (
              <ul className="space-y-3">
                {upcomingEvents.map((e) => (
                  <li key={e.id} className="text-sm">
                    <p className="font-medium">{e.title}</p>
                    <p className="text-xs text-ink-900/50 dark:text-parchment-100/50">
                      {new Date(e.startsAt).toLocaleString("de-DE")}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
