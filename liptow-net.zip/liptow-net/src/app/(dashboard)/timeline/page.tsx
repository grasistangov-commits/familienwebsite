"use client";

import { useEffect, useRef, useState } from "react";
import { FiPlus, FiTrash2, FiX, FiImage } from "react-icons/fi";

type Entry = {
  id: string;
  title: string;
  description?: string | null;
  imageUrl?: string | null;
  eventDate: string;
  author: { name: string };
};

export default function TimelinePage() {
  const [entries, setEntries] = useState<Entry[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [eventDate, setEventDate] = useState("");
  const [image, setImage] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function load() {
    const res = await fetch("/api/timeline");
    if (res.ok) setEntries((await res.json()).entries);
  }
  useEffect(() => {
    load();
  }, []);

  async function handleCreate() {
    if (!title.trim() || !eventDate) return;
    const form = new FormData();
    form.set("title", title);
    form.set("description", description);
    form.set("eventDate", eventDate);
    if (image) form.set("image", image);

    await fetch("/api/timeline", { method: "POST", body: form });
    setShowForm(false);
    setTitle("");
    setDescription("");
    setEventDate("");
    setImage(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
    load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Diesen Erinnerungs-Eintrag wirklich löschen?")) return;
    await fetch(`/api/timeline/${id}`, { method: "DELETE" });
    load();
  }

  const byYear = entries.reduce<Record<string, Entry[]>>((acc, e) => {
    const year = new Date(e.eventDate).getFullYear().toString();
    (acc[year] ??= []).push(e);
    return acc;
  }, {});

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold">Erinnerungen</h1>
          <p className="text-sm text-ink-900/60 dark:text-parchment-100/60">
            Die Chronik unserer Familie – Fotos, Momente und Ereignisse.
          </p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn-primary">
          <FiPlus size={15} />
          Erinnerung
        </button>
      </div>

      {Object.keys(byYear).length === 0 ? (
        <p className="py-12 text-center text-sm text-ink-900/50 dark:text-parchment-100/50">
          Noch keine Erinnerungen festgehalten.
        </p>
      ) : (
        <div className="space-y-10">
          {Object.entries(byYear)
            .sort((a, b) => Number(b[0]) - Number(a[0]))
            .map(([year, items]) => (
              <div key={year}>
                <h2 className="mb-4 font-display text-xl font-semibold text-moss-600 dark:text-ochre-400">
                  {year}
                </h2>
                <div className="space-y-5 border-l-2 border-moss-500/20 dark:border-ochre-400/20 pl-6">
                  {items.map((e) => (
                    <div key={e.id} className="card relative -ml-[calc(1.5rem+1px)] p-5">
                      <span className="absolute -left-[1.95rem] top-6 h-2.5 w-2.5 rounded-full bg-moss-600 dark:bg-ochre-400" />
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="text-xs text-ink-900/50 dark:text-parchment-100/50">
                            {new Date(e.eventDate).toLocaleDateString("de-DE")} · {e.author.name}
                          </p>
                          <h3 className="font-display text-lg font-semibold">{e.title}</h3>
                        </div>
                        <button onClick={() => handleDelete(e.id)}>
                          <FiTrash2 size={14} className="text-red-700 dark:text-red-400" />
                        </button>
                      </div>
                      {e.description && (
                        <p className="mt-2 text-sm text-ink-900/70 dark:text-parchment-100/70">
                          {e.description}
                        </p>
                      )}
                      {e.imageUrl && (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                          src={e.imageUrl}
                          alt={e.title}
                          className="mt-3 max-h-64 rounded-xl object-cover"
                        />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/40 p-4">
          <div className="card w-full max-w-sm space-y-3 p-6">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">Neue Erinnerung</h3>
              <button onClick={() => setShowForm(false)}>
                <FiX size={18} />
              </button>
            </div>
            <div>
              <label className="label">Titel</label>
              <input value={title} onChange={(e) => setTitle(e.target.value)} className="input" />
            </div>
            <div>
              <label className="label">Datum</label>
              <input
                type="date"
                value={eventDate}
                onChange={(e) => setEventDate(e.target.value)}
                className="input"
              />
            </div>
            <div>
              <label className="label">Beschreibung</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="input"
                rows={3}
              />
            </div>
            <div>
              <label className="label">Foto (optional)</label>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="btn-secondary w-full"
              >
                <FiImage size={15} />
                {image ? image.name : "Foto auswählen"}
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => setImage(e.target.files?.[0] ?? null)}
              />
            </div>
            <button onClick={handleCreate} className="btn-primary w-full">
              Speichern
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
