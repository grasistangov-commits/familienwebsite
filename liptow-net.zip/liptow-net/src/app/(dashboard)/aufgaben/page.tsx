"use client";

import { useEffect, useState } from "react";
import { FiPlus, FiTrash2, FiX, FiUser, FiCalendar } from "react-icons/fi";

type Task = {
  id: string;
  title: string;
  description?: string | null;
  status: "OFFEN" | "IN_ARBEIT" | "ERLEDIGT";
  priority: "NIEDRIG" | "MITTEL" | "HOCH";
  dueDate?: string | null;
  createdBy: { name: string };
  assignee?: { id: string; name: string } | null;
};
type Contact = { id: string; name: string };

const COLUMNS: { key: Task["status"]; label: string }[] = [
  { key: "OFFEN", label: "Offen" },
  { key: "IN_ARBEIT", label: "In Arbeit" },
  { key: "ERLEDIGT", label: "Erledigt" },
];

const PRIORITY_STYLES: Record<Task["priority"], string> = {
  NIEDRIG: "bg-moss-600/10 text-moss-700 dark:text-moss-400",
  MITTEL: "bg-ochre-500/15 text-ochre-600 dark:text-ochre-400",
  HOCH: "bg-red-700/10 text-red-700 dark:text-red-400",
};

export default function TasksPage() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState<Task["priority"]>("MITTEL");
  const [dueDate, setDueDate] = useState("");
  const [assigneeId, setAssigneeId] = useState("");

  async function load() {
    const res = await fetch("/api/aufgaben");
    if (res.ok) setTasks((await res.json()).tasks);
  }
  useEffect(() => {
    load();
    fetch("/api/kontakte")
      .then((r) => r.json())
      .then((d) => setContacts(d.users ?? []));
  }, []);

  async function handleCreate() {
    if (!title.trim()) return;
    await fetch("/api/aufgaben", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, description, priority, dueDate: dueDate || undefined, assigneeId }),
    });
    setShowForm(false);
    setTitle("");
    setDescription("");
    setPriority("MITTEL");
    setDueDate("");
    setAssigneeId("");
    load();
  }

  async function handleStatusChange(id: string, status: Task["status"]) {
    await fetch(`/api/aufgaben/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Aufgabe wirklich löschen?")) return;
    await fetch(`/api/aufgaben/${id}`, { method: "DELETE" });
    load();
  }

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold">Aufgabenverwaltung</h1>
          <p className="text-sm text-ink-900/60 dark:text-parchment-100/60">
            Gemeinsame Aufgabenliste der Familie.
          </p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn-primary">
          <FiPlus size={15} />
          Aufgabe
        </button>
      </div>

      <div className="grid gap-5 md:grid-cols-3">
        {COLUMNS.map((col) => (
          <div key={col.key} className="card p-4">
            <h2 className="mb-3 font-display text-sm font-semibold uppercase tracking-wide text-ink-900/60 dark:text-parchment-100/60">
              {col.label} · {tasks.filter((t) => t.status === col.key).length}
            </h2>
            <div className="space-y-3">
              {tasks
                .filter((t) => t.status === col.key)
                .map((t) => (
                  <div
                    key={t.id}
                    className="rounded-xl border border-ink-900/10 dark:border-parchment-100/10 bg-white dark:bg-ink-900/50 p-3.5"
                  >
                    <div className="mb-1.5 flex items-start justify-between gap-2">
                      <p className="text-sm font-medium">{t.title}</p>
                      <button onClick={() => handleDelete(t.id)}>
                        <FiTrash2 size={13} className="text-red-700 dark:text-red-400" />
                      </button>
                    </div>
                    {t.description && (
                      <p className="mb-2 text-xs text-ink-900/60 dark:text-parchment-100/60">
                        {t.description}
                      </p>
                    )}
                    <div className="mb-2 flex flex-wrap items-center gap-1.5">
                      <span className={`rounded-full px-2 py-0.5 text-[11px] ${PRIORITY_STYLES[t.priority]}`}>
                        {t.priority}
                      </span>
                      {t.assignee && (
                        <span className="flex items-center gap-1 rounded-full bg-ink-900/5 dark:bg-parchment-100/5 px-2 py-0.5 text-[11px]">
                          <FiUser size={10} />
                          {t.assignee.name}
                        </span>
                      )}
                      {t.dueDate && (
                        <span className="flex items-center gap-1 rounded-full bg-ink-900/5 dark:bg-parchment-100/5 px-2 py-0.5 text-[11px]">
                          <FiCalendar size={10} />
                          {new Date(t.dueDate).toLocaleDateString("de-DE")}
                        </span>
                      )}
                    </div>
                    <select
                      value={t.status}
                      onChange={(e) => handleStatusChange(t.id, e.target.value as Task["status"])}
                      className="input !py-1.5 text-xs"
                    >
                      {COLUMNS.map((c) => (
                        <option key={c.key} value={c.key}>
                          {c.label}
                        </option>
                      ))}
                    </select>
                  </div>
                ))}
              {tasks.filter((t) => t.status === col.key).length === 0 && (
                <p className="text-xs text-ink-900/40 dark:text-parchment-100/40">Keine Aufgaben.</p>
              )}
            </div>
          </div>
        ))}
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/40 p-4">
          <div className="card w-full max-w-sm space-y-3 p-6">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">Neue Aufgabe</h3>
              <button onClick={() => setShowForm(false)}>
                <FiX size={18} />
              </button>
            </div>
            <div>
              <label className="label">Titel</label>
              <input value={title} onChange={(e) => setTitle(e.target.value)} className="input" />
            </div>
            <div>
              <label className="label">Beschreibung</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="input"
                rows={2}
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="label">Priorität</label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as Task["priority"])}
                  className="input"
                >
                  <option value="NIEDRIG">Niedrig</option>
                  <option value="MITTEL">Mittel</option>
                  <option value="HOCH">Hoch</option>
                </select>
              </div>
              <div>
                <label className="label">Fällig am</label>
                <input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="input"
                />
              </div>
            </div>
            <div>
              <label className="label">Zugewiesen an</label>
              <select value={assigneeId} onChange={(e) => setAssigneeId(e.target.value)} className="input">
                <option value="">– niemand –</option>
                {contacts.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <button onClick={handleCreate} className="btn-primary w-full">
              Aufgabe anlegen
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
