"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  FiUpload,
  FiFile,
  FiDownload,
  FiTrash2,
  FiSearch,
  FiFolder,
} from "react-icons/fi";
import { formatBytes } from "@/lib/utils";

type DocItem = {
  id: string;
  name: string;
  category: string;
  storageKey: string;
  sizeBytes: string;
  mimeType: string;
  createdAt: string;
  uploadedBy: { name: string };
};

const SUGGESTED_CATEGORIES = [
  "Urkunden",
  "Zeugnisse",
  "Versicherungen",
  "Rezepte",
  "Bedienungsanleitungen",
  "Sonstiges",
];

export default function DocumentsPage() {
  const [docs, setDocs] = useState<DocItem[]>([]);
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [uploadCategory, setUploadCategory] = useState("Sonstiges");
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function load() {
    const res = await fetch("/api/dokumente");
    if (res.ok) setDocs((await res.json()).documents);
  }
  useEffect(() => {
    load();
  }, []);

  const categories = useMemo(() => {
    const set = new Set(docs.map((d) => d.category));
    SUGGESTED_CATEGORIES.forEach((c) => set.add(c));
    return Array.from(set);
  }, [docs]);

  const filtered = docs.filter(
    (d) =>
      (!activeCategory || d.category === activeCategory) &&
      d.name.toLowerCase().includes(search.toLowerCase())
  );

  async function handleUpload(fileList: FileList | null) {
    if (!fileList || fileList.length === 0) return;
    setUploading(true);
    for (const file of Array.from(fileList)) {
      const form = new FormData();
      form.set("file", file);
      form.set("category", uploadCategory);
      await fetch("/api/dokumente", { method: "POST", body: form });
    }
    setUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = "";
    load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Dieses Dokument wirklich löschen?")) return;
    await fetch(`/api/dokumente/${id}`, { method: "DELETE" });
    load();
  }

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-semibold">Dokumentenarchiv</h1>
          <p className="text-sm text-ink-900/60 dark:text-parchment-100/60">
            Urkunden, Zeugnisse, Versicherungen und weitere wichtige Unterlagen.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={uploadCategory}
            onChange={(e) => setUploadCategory(e.target.value)}
            className="input !w-auto"
          >
            {SUGGESTED_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="btn-primary"
          >
            <FiUpload size={15} />
            {uploading ? "Lädt hoch…" : "Hochladen"}
          </button>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            onChange={(e) => handleUpload(e.target.files)}
          />
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setActiveCategory(null)}
          className={`rounded-full px-3 py-1.5 text-xs font-medium ${
            !activeCategory
              ? "bg-moss-600 text-parchment-50"
              : "bg-ink-900/5 dark:bg-parchment-100/5"
          }`}
        >
          Alle
        </button>
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setActiveCategory(c)}
            className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium ${
              activeCategory === c
                ? "bg-moss-600 text-parchment-50"
                : "bg-ink-900/5 dark:bg-parchment-100/5"
            }`}
          >
            <FiFolder size={11} />
            {c}
          </button>
        ))}
      </div>

      <div className="card p-5">
        <div className="mb-4 flex justify-end">
          <div className="relative w-56">
            <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-900/40" size={14} />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Dokumente suchen…"
              className="input !pl-8"
            />
          </div>
        </div>

        {filtered.length === 0 ? (
          <p className="py-8 text-center text-sm text-ink-900/50 dark:text-parchment-100/50">
            Keine Dokumente gefunden.
          </p>
        ) : (
          <div className="divide-y divide-ink-900/5 dark:divide-parchment-100/10">
            {filtered.map((d) => (
              <div key={d.id} className="flex items-center gap-3 py-3 text-sm">
                <FiFile className="text-ink-900/40 dark:text-parchment-100/40" size={18} />
                <div className="flex-1 truncate">
                  <p className="truncate">{d.name}</p>
                  <p className="text-xs text-ink-900/40 dark:text-parchment-100/40">
                    {d.category} · {formatBytes(Number(d.sizeBytes))} · {d.uploadedBy.name}
                  </p>
                </div>
                <a
                  href={`/api/files/${encodeURIComponent(d.storageKey)}`}
                  target="_blank"
                  className="rounded-lg p-1.5 hover:bg-ink-900/5 dark:hover:bg-parchment-100/5"
                >
                  <FiDownload size={15} />
                </a>
                <button onClick={() => handleDelete(d.id)} className="rounded-lg p-1.5 hover:bg-red-700/10">
                  <FiTrash2 size={15} className="text-red-700 dark:text-red-400" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
