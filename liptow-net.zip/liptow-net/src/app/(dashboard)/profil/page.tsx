"use client";

import { useEffect, useRef, useState } from "react";
import { useSession } from "next-auth/react";
import { FiCamera, FiSave, FiAlertTriangle } from "react-icons/fi";
import { initialsFromName } from "@/lib/utils";

type ProfileData = {
  id: string;
  name: string;
  email: string;
  phone?: string | null;
  avatarUrl?: string | null;
  mustChangePassword: boolean;
};

export default function ProfilePage() {
  const { update } = useSession();
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function load() {
    const res = await fetch("/api/profile");
    if (res.ok) {
      const { user } = await res.json();
      setProfile(user);
      setName(user.name);
      setPhone(user.phone ?? "");
    }
  }
  useEffect(() => {
    load();
  }, []);

  async function handleAvatarChange(file: File | null) {
    if (!file) return;
    const form = new FormData();
    form.set("avatar", file);
    const res = await fetch("/api/profile", { method: "PATCH", body: form });
    if (res.ok) {
      load();
      update();
    }
  }

  async function handleSaveProfile() {
    setMessage(null);
    setError(null);
    const res = await fetch("/api/profile", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, phone }),
    });
    if (res.ok) {
      setMessage("Profil wurde aktualisiert.");
      load();
      update();
    } else {
      setError("Aktualisierung fehlgeschlagen.");
    }
  }

  async function handleChangePassword() {
    setMessage(null);
    setError(null);
    if (newPassword.length < 8) {
      setError("Das neue Passwort muss mindestens 8 Zeichen lang sein.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setError("Die Passwörter stimmen nicht überein.");
      return;
    }
    const res = await fetch("/api/profile", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ currentPassword, newPassword }),
    });
    const data = await res.json();
    if (res.ok) {
      setMessage("Passwort wurde geändert.");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      load();
    } else {
      setError(data.error ?? "Passwort konnte nicht geändert werden.");
    }
  }

  if (!profile) return null;

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Mein Profil</h1>
        <p className="text-sm text-ink-900/60 dark:text-parchment-100/60">
          Persönliche Einstellungen und Zugangsdaten.
        </p>
      </div>

      {profile.mustChangePassword && (
        <div className="flex items-start gap-3 rounded-xl bg-ochre-500/10 p-4 text-sm text-ochre-700 dark:text-ochre-400">
          <FiAlertTriangle className="mt-0.5 shrink-0" />
          <p>
            Du verwendest noch dein Einmalpasswort. Bitte lege jetzt weiter unten ein eigenes
            Passwort fest.
          </p>
        </div>
      )}

      {message && (
        <div className="rounded-xl bg-moss-600/10 p-3 text-sm text-moss-700 dark:text-moss-400">
          {message}
        </div>
      )}
      {error && (
        <div className="rounded-xl bg-red-700/10 p-3 text-sm text-red-700 dark:text-red-400">
          {error}
        </div>
      )}

      <div className="card flex items-center gap-5 p-6">
        <div className="relative">
          {profile.avatarUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={profile.avatarUrl} alt={profile.name} className="h-20 w-20 rounded-full object-cover" />
          ) : (
            <span className="flex h-20 w-20 items-center justify-center rounded-full bg-moss-600/15 text-xl font-semibold text-moss-700 dark:bg-ochre-400/15 dark:text-ochre-400">
              {initialsFromName(profile.name)}
            </span>
          )}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="absolute -bottom-1 -right-1 flex h-8 w-8 items-center justify-center rounded-full bg-moss-600 text-parchment-50 shadow-sm"
          >
            <FiCamera size={13} />
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => handleAvatarChange(e.target.files?.[0] ?? null)}
          />
        </div>
        <div>
          <p className="font-medium">{profile.name}</p>
          <p className="text-sm text-ink-900/60 dark:text-parchment-100/60">{profile.email}</p>
        </div>
      </div>

      <div className="card space-y-3 p-6">
        <h2 className="font-display text-lg font-semibold">Stammdaten</h2>
        <div>
          <label className="label">Name</label>
          <input value={name} onChange={(e) => setName(e.target.value)} className="input" />
        </div>
        <div>
          <label className="label">Telefonnummer</label>
          <input value={phone} onChange={(e) => setPhone(e.target.value)} className="input" />
        </div>
        <button onClick={handleSaveProfile} className="btn-primary">
          <FiSave size={15} />
          Speichern
        </button>
      </div>

      <div className="card space-y-3 p-6">
        <h2 className="font-display text-lg font-semibold">Passwort ändern</h2>
        {!profile.mustChangePassword && (
          <div>
            <label className="label">Aktuelles Passwort</label>
            <input
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              className="input"
            />
          </div>
        )}
        <div>
          <label className="label">Neues Passwort</label>
          <input
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            className="input"
          />
        </div>
        <div>
          <label className="label">Neues Passwort bestätigen</label>
          <input
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className="input"
          />
        </div>
        <button onClick={handleChangePassword} className="btn-primary">
          Passwort ändern
        </button>
      </div>
    </div>
  );
}
