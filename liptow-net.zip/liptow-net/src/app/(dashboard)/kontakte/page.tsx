"use client";

import { useEffect, useState } from "react";
import { FiSearch, FiMail, FiPhone } from "react-icons/fi";
import { initialsFromName } from "@/lib/utils";

type Contact = {
  id: string;
  name: string;
  email: string;
  phone?: string | null;
  avatarUrl?: string | null;
  role: "ADMIN" | "MEMBER";
};

export default function ContactsPage() {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetch("/api/kontakte")
      .then((r) => r.json())
      .then((d) => setContacts(d.users ?? []));
  }, []);

  const filtered = contacts.filter((c) => c.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-semibold">Kontakte</h1>
          <p className="text-sm text-ink-900/60 dark:text-parchment-100/60">
            Alle Familienmitglieder auf einen Blick.
          </p>
        </div>
        <div className="relative w-56">
          <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-900/40" size={14} />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Kontakt suchen…"
            className="input !pl-8"
          />
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {filtered.map((c) => (
          <div key={c.id} className="card flex items-center gap-4 p-5">
            {c.avatarUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={c.avatarUrl} alt={c.name} className="h-12 w-12 rounded-full object-cover" />
            ) : (
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-moss-600/15 text-sm font-semibold text-moss-700 dark:bg-ochre-400/15 dark:text-ochre-400">
                {initialsFromName(c.name)}
              </span>
            )}
            <div className="min-w-0 flex-1">
              <p className="font-medium">{c.name}</p>
              <p className="flex items-center gap-1.5 truncate text-xs text-ink-900/50 dark:text-parchment-100/50">
                <FiMail size={11} />
                {c.email}
              </p>
              {c.phone && (
                <p className="flex items-center gap-1.5 text-xs text-ink-900/50 dark:text-parchment-100/50">
                  <FiPhone size={11} />
                  {c.phone}
                </p>
              )}
            </div>
            {c.role === "ADMIN" && (
              <span className="shrink-0 rounded-full bg-ochre-500/15 px-2 py-0.5 text-[11px] text-ochre-600 dark:text-ochre-400">
                Admin
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
