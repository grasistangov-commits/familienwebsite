"use client";

import { FormEvent, useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useTheme } from "@/components/ThemeProvider";
import { FiSun, FiMoon, FiArrowRight, FiAlertCircle } from "react-icons/fi";

export default function LoginPage() {
  const router = useRouter();
  const { theme, toggle } = useTheme();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const result = await signIn("credentials", {
      email,
      password,
      redirect: false,
    });

    setLoading(false);

    if (result?.error) {
      setError("E-Mail oder Passwort ist falsch.");
      return;
    }

    router.push("/dashboard");
    router.refresh();
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-parchment-50 dark:bg-ink-950 transition-colors duration-300">
      {/* Signaturelement: wachsende Jahresringe – Generationen einer Familie */}
      <div
        aria-hidden
        className="pointer-events-none absolute -right-40 -top-40 h-[560px] w-[560px] text-moss-600/[0.08] dark:text-ochre-400/[0.07]"
      >
        <svg viewBox="0 0 560 560" className="h-full w-full">
          {[40, 90, 140, 190, 240, 290].map((r, i) => (
            <circle
              key={r}
              cx="280"
              cy="280"
              r={r}
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeDasharray="1000"
              className="animate-grow-ring"
              style={{ animationDelay: `${i * 150}ms` }}
            />
          ))}
        </svg>
      </div>
      <div
        aria-hidden
        className="pointer-events-none absolute -left-32 bottom-0 h-[380px] w-[380px] text-ochre-500/[0.08] dark:text-moss-400/[0.06]"
      >
        <svg viewBox="0 0 380 380" className="h-full w-full">
          {[30, 65, 100, 135].map((r, i) => (
            <circle
              key={r}
              cx="190"
              cy="190"
              r={r}
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeDasharray="1000"
              className="animate-grow-ring"
              style={{ animationDelay: `${400 + i * 150}ms` }}
            />
          ))}
        </svg>
      </div>

      <button
        onClick={toggle}
        aria-label="Farbmodus wechseln"
        className="absolute right-6 top-6 z-10 flex h-10 w-10 items-center justify-center rounded-full border border-ink-900/10 dark:border-parchment-100/15 bg-white/60 dark:bg-ink-900/60 backdrop-blur transition hover:scale-105"
      >
        {theme === "light" ? <FiMoon size={17} /> : <FiSun size={17} />}
      </button>

      <div className="relative z-10 flex min-h-screen items-center justify-center px-6">
        <div className="w-full max-w-sm animate-fade-up">
          <div className="mb-10 text-center">
            <p className="mb-3 font-display italic text-sm tracking-wide text-moss-600 dark:text-ochre-400">
              Familie Liptow
            </p>
            <h1 className="font-display text-4xl font-semibold text-ink-900 dark:text-parchment-100">
              Liptow<span className="text-moss-600 dark:text-ochre-400">.net</span>
            </h1>
            <p className="mt-3 text-sm text-ink-900/60 dark:text-parchment-100/60">
              Das private Archiv, der Treffpunkt und das Gedächtnis unserer Familie.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="card space-y-4 p-7">
            <div>
              <label className="label" htmlFor="email">
                E-Mail-Adresse
              </label>
              <input
                id="email"
                type="email"
                required
                autoFocus
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input"
                placeholder="name@liptow.net"
              />
            </div>
            <div>
              <label className="label" htmlFor="password">
                Passwort
              </label>
              <input
                id="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="input"
                placeholder="••••••••"
              />
            </div>

            {error && (
              <div className="flex items-center gap-2 rounded-lg bg-red-700/10 px-3 py-2 text-sm text-red-700 dark:text-red-400">
                <FiAlertCircle className="shrink-0" />
                {error}
              </div>
            )}

            <button type="submit" disabled={loading} className="btn-primary w-full">
              {loading ? "Wird angemeldet…" : "Anmelden"}
              {!loading && <FiArrowRight size={16} />}
            </button>
          </form>

          <p className="mt-6 text-center text-xs text-ink-900/40 dark:text-parchment-100/40">
            Kein öffentlicher Zugang. Neue Konten werden ausschließlich vom
            Administrator eingerichtet.
          </p>
        </div>
      </div>
    </main>
  );
}
