import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/utils";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const pages = await prisma.wikiPage.findMany({
    orderBy: { updatedAt: "desc" },
    include: { author: { select: { name: true } } },
  });
  return NextResponse.json({ pages });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const { title, content, category } = await req.json();
  if (!title?.trim()) return NextResponse.json({ error: "Titel ist erforderlich." }, { status: 400 });

  let slug = slugify(title);
  const existing = await prisma.wikiPage.findUnique({ where: { slug } });
  if (existing) slug = `${slug}-${Date.now().toString(36)}`;

  const page = await prisma.wikiPage.create({
    data: {
      title: title.trim(),
      slug,
      content: content ?? "",
      category: category?.trim() || "Allgemein",
      authorId: session.user.id,
    },
  });

  return NextResponse.json({ page });
}
