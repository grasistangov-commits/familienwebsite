import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const page = await prisma.wikiPage.findUnique({
    where: { id: params.id },
    include: { author: { select: { name: true } } },
  });
  if (!page) return NextResponse.json({ error: "Seite nicht gefunden." }, { status: 404 });
  return NextResponse.json({ page });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const { title, content, category } = await req.json();
  const page = await prisma.wikiPage.update({
    where: { id: params.id },
    data: {
      ...(title !== undefined ? { title } : {}),
      ...(content !== undefined ? { content } : {}),
      ...(category !== undefined ? { category } : {}),
    },
  });
  return NextResponse.json({ page });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const page = await prisma.wikiPage.findUnique({ where: { id: params.id } });
  if (!page) return NextResponse.json({ error: "Seite nicht gefunden." }, { status: 404 });

  const isAdmin = session.user.role === "ADMIN";
  if (page.authorId !== session.user.id && !isAdmin) {
    return NextResponse.json({ error: "Keine Berechtigung." }, { status: 403 });
  }

  await prisma.wikiPage.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
