import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { promises as fs } from "fs";
import path from "path";
import { authOptions } from "@/lib/auth";
import { STORAGE_ROOT } from "@/lib/storage";

// Liefert Dateien aus dem lokalen Storage nur an eingeloggte Familienmitglieder aus.
// Dadurch sind hochgeladene Bilder/Dokumente nie öffentlich erreichbar.
export async function GET(
  _req: NextRequest,
  { params }: { params: { key: string[] } }
) {
  const session = await getServerSession(authOptions);
  if (!session) {
    return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });
  }

  const relativePath = params.key.join("/");
  const normalized = path.normalize(relativePath);

  // Verhindert das Verlassen des Storage-Root-Verzeichnisses (Path Traversal)
  if (normalized.includes("..")) {
    return NextResponse.json({ error: "Ungültiger Pfad." }, { status: 400 });
  }

  const fullPath = path.join(STORAGE_ROOT, normalized);

  try {
    const data = await fs.readFile(fullPath);
    const ext = path.extname(fullPath).toLowerCase();
    const contentType =
      {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".webp": "image/webp",
        ".pdf": "application/pdf",
        ".mp4": "video/mp4",
        ".mov": "video/quicktime",
        ".txt": "text/plain",
      }[ext] || "application/octet-stream";

    return new NextResponse(data, {
      headers: {
        "Content-Type": contentType,
        "Cache-Control": "private, max-age=3600",
      },
    });
  } catch {
    return NextResponse.json({ error: "Datei nicht gefunden." }, { status: 404 });
  }
}
