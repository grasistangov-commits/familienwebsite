import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const tasks = await prisma.task.findMany({
    orderBy: [{ status: "asc" }, { dueDate: "asc" }],
    include: {
      createdBy: { select: { name: true } },
      assignee: { select: { id: true, name: true } },
    },
  });
  return NextResponse.json({ tasks });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const { title, description, priority, dueDate, assigneeId } = await req.json();
  if (!title?.trim()) return NextResponse.json({ error: "Titel ist erforderlich." }, { status: 400 });

  const task = await prisma.task.create({
    data: {
      title: title.trim(),
      description,
      priority: priority ?? "MITTEL",
      dueDate: dueDate ? new Date(dueDate) : undefined,
      assigneeId: assigneeId || undefined,
      createdById: session.user.id,
    },
    include: {
      createdBy: { select: { name: true } },
      assignee: { select: { id: true, name: true } },
    },
  });

  return NextResponse.json({ task });
}
