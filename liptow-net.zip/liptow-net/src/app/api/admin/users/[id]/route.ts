import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import bcrypt from "bcryptjs";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { generateTempPassword } from "@/lib/utils";

async function requireAdmin() {
  const session = await getServerSession(authOptions);
  if (!session) return { error: NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 }) };
  if (session.user.role !== "ADMIN") {
    return { error: NextResponse.json({ error: "Nur für Administratoren." }, { status: 403 }) };
  }
  return { session };
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const { error, session } = await requireAdmin();
  if (error) return error;

  const body = await req.json();
  const { action } = body;

  if (action === "resetPassword") {
    const tempPassword = generateTempPassword();
    const passwordHash = await bcrypt.hash(tempPassword, 12);
    await prisma.user.update({
      where: { id: params.id },
      data: { passwordHash, mustChangePassword: true },
    });
    await prisma.activityLog.create({
      data: {
        action: "PASSWORD_RESET",
        detail: "Passwort wurde vom Administrator zurückgesetzt.",
        userId: session!.user.id,
      },
    });
    return NextResponse.json({ tempPassword });
  }

  if (action === "toggleLock") {
    const user = await prisma.user.findUnique({ where: { id: params.id } });
    if (!user) return NextResponse.json({ error: "Benutzer nicht gefunden." }, { status: 404 });
    const updated = await prisma.user.update({
      where: { id: params.id },
      data: { isLocked: !user.isLocked },
    });
    return NextResponse.json({ user: updated });
  }

  // Allgemeines Bearbeiten von Stammdaten
  const { name, email, role, storageQuotaBytes } = body;
  const updated = await prisma.user.update({
    where: { id: params.id },
    data: {
      ...(name !== undefined ? { name } : {}),
      ...(email !== undefined ? { email: email.toLowerCase().trim() } : {}),
      ...(role !== undefined ? { role } : {}),
      ...(storageQuotaBytes !== undefined
        ? { storageQuotaBytes: BigInt(storageQuotaBytes) }
        : {}),
    },
  });

  return NextResponse.json({
    user: { ...updated, storageQuotaBytes: updated.storageQuotaBytes.toString() },
  });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const { error, session } = await requireAdmin();
  if (error) return error;

  if (params.id === session!.user.id) {
    return NextResponse.json(
      { error: "Du kannst dein eigenes Konto nicht löschen." },
      { status: 400 }
    );
  }

  await prisma.user.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
