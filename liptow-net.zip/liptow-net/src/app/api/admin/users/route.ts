import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import bcrypt from "bcryptjs";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { generateTempPassword } from "@/lib/utils";

async function requireAdmin() {
  const session = await getServerSession(authOptions);
  if (!session) return { error: NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 }) };
  if (session.user.role !== "ADMIN") {
    return { error: NextResponse.json({ error: "Nur für Administratoren." }, { status: 403 }) };
  }
  return { session };
}

export async function GET() {
  const { error } = await requireAdmin();
  if (error) return error;

  const users = await prisma.user.findMany({
    orderBy: { createdAt: "asc" },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      isLocked: true,
      mustChangePassword: true,
      storageUsedBytes: true,
      storageQuotaBytes: true,
      createdAt: true,
      avatarUrl: true,
    },
  });

  return NextResponse.json({
    users: users.map((u) => ({
      ...u,
      storageUsedBytes: u.storageUsedBytes.toString(),
      storageQuotaBytes: u.storageQuotaBytes.toString(),
    })),
  });
}

export async function POST(req: NextRequest) {
  const { error, session } = await requireAdmin();
  if (error) return error;

  const { name, email, role } = await req.json();
  if (!name?.trim() || !email?.trim()) {
    return NextResponse.json({ error: "Name und E-Mail sind erforderlich." }, { status: 400 });
  }

  const existing = await prisma.user.findUnique({ where: { email: email.toLowerCase().trim() } });
  if (existing) {
    return NextResponse.json({ error: "Diese E-Mail-Adresse wird bereits verwendet." }, { status: 409 });
  }

  const tempPassword = generateTempPassword();
  const passwordHash = await bcrypt.hash(tempPassword, 12);

  const user = await prisma.user.create({
    data: {
      name: name.trim(),
      email: email.toLowerCase().trim(),
      passwordHash,
      role: role === "ADMIN" ? "ADMIN" : "MEMBER",
      mustChangePassword: true,
    },
  });

  await prisma.activityLog.create({
    data: {
      action: "USER_CREATED",
      detail: `Benutzer "${user.name}" wurde angelegt.`,
      userId: session!.user.id,
    },
  });

  return NextResponse.json({ user, tempPassword });
}
