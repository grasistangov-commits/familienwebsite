import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const { name, parentId, userId } = await req.json();
  const isAdmin = session.user.role === "ADMIN";
  const targetUserId = userId && isAdmin ? userId : session.user.id;

  if (!name?.trim()) {
    return NextResponse.json({ error: "Name darf nicht leer sein." }, { status: 400 });
  }

  const folder = await prisma.folder.create({
    data: { name: name.trim(), parentId: parentId || undefined, ownerId: targetUserId },
  });

  return NextResponse.json({ folder });
}
