import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { deleteStoredFile } from "@/lib/storage";

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const entry = await prisma.fileEntry.findUnique({ where: { id: params.id } });
  if (!entry) return NextResponse.json({ error: "Datei nicht gefunden." }, { status: 404 });

  const isAdmin = session.user.role === "ADMIN";
  if (entry.ownerId !== session.user.id && !isAdmin) {
    return NextResponse.json({ error: "Keine Berechtigung." }, { status: 403 });
  }

  await deleteStoredFile(entry.storageKey);
  await prisma.fileEntry.delete({ where: { id: params.id } });
  await prisma.user.update({
    where: { id: entry.ownerId },
    data: { storageUsedBytes: { decrement: entry.sizeBytes } },
  });

  return NextResponse.json({ ok: true });
}
