import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { saveUploadedFile } from "@/lib/storage";

// Ermittelt den Ziel-Benutzer: Admins können optional ?userId=... übergeben,
// um den Cloudspeicher eines anderen Familienmitglieds einzusehen.
async function resolveTargetUserId(req: NextRequest, sessionUserId: string, isAdmin: boolean) {
  const requested = req.nextUrl.searchParams.get("userId");
  if (requested && isAdmin) return requested;
  return sessionUserId;
}

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const isAdmin = session.user.role === "ADMIN";
  const targetUserId = await resolveTargetUserId(req, session.user.id, isAdmin);
  const folderId = req.nextUrl.searchParams.get("folderId");

  const [folders, files, targetUser, allUsers] = await Promise.all([
    prisma.folder.findMany({
      where: { ownerId: targetUserId, parentId: folderId ?? null },
      orderBy: { name: "asc" },
    }),
    prisma.fileEntry.findMany({
      where: { ownerId: targetUserId, folderId: folderId ?? null },
      orderBy: { createdAt: "desc" },
    }),
    prisma.user.findUnique({
      where: { id: targetUserId },
      select: { name: true, storageUsedBytes: true, storageQuotaBytes: true },
    }),
    isAdmin
      ? prisma.user.findMany({ select: { id: true, name: true }, orderBy: { name: "asc" } })
      : Promise.resolve([]),
  ]);

  return NextResponse.json({
    folders,
    files: files.map((f) => ({ ...f, sizeBytes: f.sizeBytes.toString() })),
    usedBytes: targetUser?.storageUsedBytes.toString() ?? "0",
    quotaBytes: targetUser?.storageQuotaBytes.toString() ?? "0",
    targetUserName: targetUser?.name,
    targetUserId,
    allUsers,
  });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const isAdmin = session.user.role === "ADMIN";
  const form = await req.formData();
  const file = form.get("file") as File | null;
  const folderId = (form.get("folderId") as string | null) || null;
  const targetUserId = (form.get("userId") as string | null) || session.user.id;

  if (targetUserId !== session.user.id && !isAdmin) {
    return NextResponse.json({ error: "Keine Berechtigung." }, { status: 403 });
  }

  if (!file) return NextResponse.json({ error: "Keine Datei übermittelt." }, { status: 400 });

  const user = await prisma.user.findUnique({ where: { id: targetUserId } });
  if (!user) return NextResponse.json({ error: "Benutzer nicht gefunden." }, { status: 404 });

  if (user.storageUsedBytes + BigInt(file.size) > user.storageQuotaBytes) {
    return NextResponse.json(
      { error: "Speicherlimit erreicht. Weitere Uploads sind nicht möglich." },
      { status: 413 }
    );
  }

  const saved = await saveUploadedFile(file, "cloud", targetUserId);

  const entry = await prisma.fileEntry.create({
    data: {
      name: saved.originalName,
      sizeBytes: saved.sizeBytes,
      mimeType: saved.mimeType,
      storageKey: saved.storageKey,
      folderId: folderId || undefined,
      ownerId: targetUserId,
    },
  });

  await prisma.user.update({
    where: { id: targetUserId },
    data: { storageUsedBytes: { increment: saved.sizeBytes } },
  });

  return NextResponse.json({ file: { ...entry, sizeBytes: entry.sizeBytes.toString() } });
}
