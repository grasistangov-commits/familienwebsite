import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const body = await req.json();
  const member = await prisma.familyMember.update({
    where: { id: params.id },
    data: {
      ...(body.firstName !== undefined ? { firstName: body.firstName } : {}),
      ...(body.lastName !== undefined ? { lastName: body.lastName } : {}),
      ...(body.birthDate !== undefined
        ? { birthDate: body.birthDate ? new Date(body.birthDate) : null }
        : {}),
      ...(body.deathDate !== undefined
        ? { deathDate: body.deathDate ? new Date(body.deathDate) : null }
        : {}),
      ...(body.notes !== undefined ? { notes: body.notes } : {}),
      ...(body.photoUrl !== undefined ? { photoUrl: body.photoUrl } : {}),
      ...(body.fatherId !== undefined ? { fatherId: body.fatherId || null } : {}),
      ...(body.motherId !== undefined ? { motherId: body.motherId || null } : {}),
    },
  });

  return NextResponse.json({ member });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  // Nur der Administrator darf den Stammbaum vollständig bearbeiten/löschen
  if (session.user.role !== "ADMIN") {
    return NextResponse.json({ error: "Nur für Administratoren." }, { status: 403 });
  }

  await prisma.familyMember.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
