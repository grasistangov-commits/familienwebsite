import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const members = await prisma.familyMember.findMany({
    include: {
      partnerships: { include: { partnerB: { select: { id: true, firstName: true, lastName: true } } } },
      partnershipsB: { include: { partnerA: { select: { id: true, firstName: true, lastName: true } } } },
    },
    orderBy: { createdAt: "asc" },
  });

  return NextResponse.json({ members });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const { firstName, lastName, birthDate, deathDate, notes, fatherId, motherId, photoUrl, partnerId } =
    await req.json();

  if (!firstName?.trim() || !lastName?.trim()) {
    return NextResponse.json({ error: "Vor- und Nachname sind erforderlich." }, { status: 400 });
  }

  const member = await prisma.familyMember.create({
    data: {
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      birthDate: birthDate ? new Date(birthDate) : undefined,
      deathDate: deathDate ? new Date(deathDate) : undefined,
      notes,
      photoUrl,
      fatherId: fatherId || undefined,
      motherId: motherId || undefined,
    },
  });

  if (partnerId) {
    await prisma.familyPartnership.create({
      data: { partnerAId: member.id, partnerBId: partnerId },
    });
  }

  return NextResponse.json({ member });
}
