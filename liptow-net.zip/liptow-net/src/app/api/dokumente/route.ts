import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { saveUploadedFile } from "@/lib/storage";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const documents = await prisma.document.findMany({
    orderBy: { createdAt: "desc" },
    include: { uploadedBy: { select: { name: true } } },
  });

  return NextResponse.json({
    documents: documents.map((d) => ({ ...d, sizeBytes: d.sizeBytes.toString() })),
  });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const form = await req.formData();
  const file = form.get("file") as File | null;
  const category = (form.get("category") as string | null) || "Sonstiges";

  if (!file) return NextResponse.json({ error: "Keine Datei übermittelt." }, { status: 400 });

  const saved = await saveUploadedFile(file, "documents", session.user.id);

  const doc = await prisma.document.create({
    data: {
      name: saved.originalName,
      category,
      storageKey: saved.storageKey,
      sizeBytes: saved.sizeBytes,
      mimeType: saved.mimeType,
      uploadedById: session.user.id,
    },
  });

  return NextResponse.json({ document: { ...doc, sizeBytes: doc.sizeBytes.toString() } });
}
