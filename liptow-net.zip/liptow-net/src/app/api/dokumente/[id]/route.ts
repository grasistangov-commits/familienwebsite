import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { deleteStoredFile } from "@/lib/storage";

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const doc = await prisma.document.findUnique({ where: { id: params.id } });
  if (!doc) return NextResponse.json({ error: "Dokument nicht gefunden." }, { status: 404 });

  const isAdmin = session.user.role === "ADMIN";
  if (doc.uploadedById !== session.user.id && !isAdmin) {
    return NextResponse.json({ error: "Keine Berechtigung." }, { status: 403 });
  }

  await deleteStoredFile(doc.storageKey);
  await prisma.document.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
