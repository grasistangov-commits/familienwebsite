import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { saveUploadedFile } from "@/lib/storage";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const messages = await prisma.message.findMany({
    orderBy: { createdAt: "asc" },
    take: 200,
    include: {
      sender: { select: { id: true, name: true, avatarUrl: true } },
      replyTo: {
        include: { sender: { select: { name: true } } },
      },
    },
  });

  return NextResponse.json({ messages });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const form = await req.formData();
  const content = (form.get("content") as string | null) ?? "";
  const replyToId = (form.get("replyToId") as string | null) || null;
  const file = form.get("file") as File | null;

  if (!content.trim() && !file) {
    return NextResponse.json({ error: "Nachricht darf nicht leer sein." }, { status: 400 });
  }

  let imageUrl: string | undefined;
  let videoUrl: string | undefined;
  let fileUrl: string | undefined;

  if (file && file.size > 0) {
    const saved = await saveUploadedFile(file, "chat", session.user.id);
    const url = `/api/files/${encodeURIComponent(saved.storageKey)}`;
    if (saved.mimeType.startsWith("image/")) imageUrl = url;
    else if (saved.mimeType.startsWith("video/")) videoUrl = url;
    else fileUrl = url;
  }

  const message = await prisma.message.create({
    data: {
      content: content.trim(),
      imageUrl,
      videoUrl,
      fileUrl,
      senderId: session.user.id,
      replyToId: replyToId || undefined,
    },
    include: {
      sender: { select: { id: true, name: true, avatarUrl: true } },
      replyTo: { include: { sender: { select: { name: true } } } },
    },
  });

  return NextResponse.json({ message });
}
