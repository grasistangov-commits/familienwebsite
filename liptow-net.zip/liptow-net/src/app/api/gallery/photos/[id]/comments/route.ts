import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const { content } = await req.json();
  if (!content?.trim()) {
    return NextResponse.json({ error: "Kommentar darf nicht leer sein." }, { status: 400 });
  }

  const comment = await prisma.photoComment.create({
    data: { content: content.trim(), photoId: params.id, authorId: session.user.id },
    include: { author: { select: { name: true } } },
  });

  return NextResponse.json({ comment });
}
