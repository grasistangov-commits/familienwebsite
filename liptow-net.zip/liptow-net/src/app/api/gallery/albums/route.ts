import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const albums = await prisma.album.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      createdBy: { select: { name: true } },
      _count: { select: { photos: true } },
      photos: { take: 1, orderBy: { createdAt: "desc" } },
    },
  });
  return NextResponse.json({ albums });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const { title, description } = await req.json();
  if (!title?.trim()) return NextResponse.json({ error: "Titel ist erforderlich." }, { status: 400 });

  const album = await prisma.album.create({
    data: { title: title.trim(), description, createdById: session.user.id },
  });
  return NextResponse.json({ album });
}
