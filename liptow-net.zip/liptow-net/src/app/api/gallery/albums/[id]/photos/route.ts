import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { saveUploadedFile } from "@/lib/storage";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const album = await prisma.album.findUnique({ where: { id: params.id } });
  if (!album) return NextResponse.json({ error: "Album nicht gefunden." }, { status: 404 });

  const form = await req.formData();
  const files = form.getAll("files") as File[];
  const caption = (form.get("caption") as string | null) || undefined;

  if (!files || files.length === 0) {
    return NextResponse.json({ error: "Keine Datei übermittelt." }, { status: 400 });
  }

  const created = [];
  for (const file of files) {
    if (!file || file.size === 0) continue;
    const saved = await saveUploadedFile(file, "gallery", session.user.id);
    const url = `/api/files/${encodeURIComponent(saved.storageKey)}`;
    const type = saved.mimeType.startsWith("video/") ? "video" : "image";

    const photo = await prisma.photo.create({
      data: {
        url,
        type,
        caption,
        albumId: params.id,
        uploadedById: session.user.id,
      },
    });
    created.push(photo);

    if (!album.coverUrl && type === "image") {
      await prisma.album.update({ where: { id: params.id }, data: { coverUrl: url } });
    }
  }

  return NextResponse.json({ photos: created });
}
