import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { deleteStoredFile } from "@/lib/storage";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const album = await prisma.album.findUnique({
    where: { id: params.id },
    include: {
      createdBy: { select: { name: true } },
      photos: {
        orderBy: { createdAt: "desc" },
        include: {
          uploadedBy: { select: { name: true } },
          comments: { include: { author: { select: { name: true } } }, orderBy: { createdAt: "asc" } },
        },
      },
    },
  });
  if (!album) return NextResponse.json({ error: "Album nicht gefunden." }, { status: 404 });
  return NextResponse.json({ album });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const album = await prisma.album.findUnique({ where: { id: params.id }, include: { photos: true } });
  if (!album) return NextResponse.json({ error: "Album nicht gefunden." }, { status: 404 });

  const isAdmin = session.user.role === "ADMIN";
  if (album.createdById !== session.user.id && !isAdmin) {
    return NextResponse.json({ error: "Keine Berechtigung." }, { status: 403 });
  }

  for (const photo of album.photos) {
    const key = photo.url.replace("/api/files/", "");
    await deleteStoredFile(decodeURIComponent(key));
  }
  await prisma.album.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
