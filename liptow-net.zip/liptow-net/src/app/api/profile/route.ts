import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import bcrypt from "bcryptjs";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { saveUploadedFile } from "@/lib/storage";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    select: {
      id: true,
      name: true,
      email: true,
      phone: true,
      avatarUrl: true,
      mustChangePassword: true,
      birthDate: true,
    },
  });
  return NextResponse.json({ user });
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const contentType = req.headers.get("content-type") || "";

  // Avatar-Upload (multipart/form-data)
  if (contentType.includes("multipart/form-data")) {
    const form = await req.formData();
    const avatar = form.get("avatar") as File | null;
    if (!avatar) return NextResponse.json({ error: "Keine Datei übermittelt." }, { status: 400 });

    const saved = await saveUploadedFile(avatar, "avatars", session.user.id);
    const avatarUrl = `/api/files/${encodeURIComponent(saved.storageKey)}`;
    const user = await prisma.user.update({
      where: { id: session.user.id },
      data: { avatarUrl },
    });
    return NextResponse.json({ user });
  }

  // Stammdaten / Passwort (JSON)
  const body = await req.json();
  const { name, phone, currentPassword, newPassword } = body;

  if (newPassword) {
    const user = await prisma.user.findUnique({ where: { id: session.user.id } });
    if (!user) return NextResponse.json({ error: "Benutzer nicht gefunden." }, { status: 404 });

    if (!user.mustChangePassword) {
      const valid = currentPassword
        ? await bcrypt.compare(currentPassword, user.passwordHash)
        : false;
      if (!valid) {
        return NextResponse.json({ error: "Aktuelles Passwort ist falsch." }, { status: 400 });
      }
    }

    const passwordHash = await bcrypt.hash(newPassword, 12);
    await prisma.user.update({
      where: { id: session.user.id },
      data: { passwordHash, mustChangePassword: false },
    });
  }

  if (name !== undefined || phone !== undefined) {
    await prisma.user.update({
      where: { id: session.user.id },
      data: {
        ...(name !== undefined ? { name } : {}),
        ...(phone !== undefined ? { phone } : {}),
      },
    });
  }

  const updated = await prisma.user.findUnique({
    where: { id: session.user.id },
    select: { id: true, name: true, email: true, phone: true, avatarUrl: true, mustChangePassword: true },
  });

  return NextResponse.json({ user: updated });
}
