import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

async function canEdit(eventId: string, userId: string, isAdmin: boolean) {
  if (isAdmin) return true;
  const event = await prisma.calendarEvent.findUnique({ where: { id: eventId } });
  return event?.createdById === userId;
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const allowed = await canEdit(params.id, session.user.id, session.user.role === "ADMIN");
  if (!allowed) return NextResponse.json({ error: "Keine Berechtigung." }, { status: 403 });

  const body = await req.json();
  const event = await prisma.calendarEvent.update({
    where: { id: params.id },
    data: {
      ...(body.title !== undefined ? { title: body.title } : {}),
      ...(body.description !== undefined ? { description: body.description } : {}),
      ...(body.startsAt !== undefined ? { startsAt: new Date(body.startsAt) } : {}),
      ...(body.endsAt !== undefined ? { endsAt: new Date(body.endsAt) } : {}),
      ...(body.allDay !== undefined ? { allDay: body.allDay } : {}),
      ...(body.reminder !== undefined ? { reminder: body.reminder } : {}),
    },
  });

  return NextResponse.json({ event });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const allowed = await canEdit(params.id, session.user.id, session.user.role === "ADMIN");
  if (!allowed) return NextResponse.json({ error: "Keine Berechtigung." }, { status: 403 });

  await prisma.calendarEvent.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
