import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const events = await prisma.calendarEvent.findMany({
    orderBy: { startsAt: "asc" },
    include: { createdBy: { select: { name: true } } },
  });
  return NextResponse.json({ events });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const { title, description, startsAt, endsAt, allDay, reminder } = await req.json();
  if (!title?.trim() || !startsAt || !endsAt) {
    return NextResponse.json({ error: "Titel, Start und Ende sind erforderlich." }, { status: 400 });
  }

  const event = await prisma.calendarEvent.create({
    data: {
      title: title.trim(),
      description,
      startsAt: new Date(startsAt),
      endsAt: new Date(endsAt),
      allDay: !!allDay,
      reminder: !!reminder,
      createdById: session.user.id,
    },
    include: { createdBy: { select: { name: true } } },
  });

  return NextResponse.json({ event });
}
