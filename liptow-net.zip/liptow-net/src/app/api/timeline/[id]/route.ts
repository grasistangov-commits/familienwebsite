import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { deleteStoredFile } from "@/lib/storage";

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const entry = await prisma.timelineEntry.findUnique({ where: { id: params.id } });
  if (!entry) return NextResponse.json({ error: "Eintrag nicht gefunden." }, { status: 404 });

  const isAdmin = session.user.role === "ADMIN";
  if (entry.authorId !== session.user.id && !isAdmin) {
    return NextResponse.json({ error: "Keine Berechtigung." }, { status: 403 });
  }

  if (entry.imageUrl) {
    const key = decodeURIComponent(entry.imageUrl.replace("/api/files/", ""));
    await deleteStoredFile(key);
  }
  await prisma.timelineEntry.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
