import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { saveUploadedFile } from "@/lib/storage";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const entries = await prisma.timelineEntry.findMany({
    orderBy: { eventDate: "desc" },
    include: { author: { select: { name: true } } },
  });
  return NextResponse.json({ entries });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Nicht angemeldet." }, { status: 401 });

  const form = await req.formData();
  const title = (form.get("title") as string | null) ?? "";
  const description = (form.get("description") as string | null) || undefined;
  const eventDate = form.get("eventDate") as string | null;
  const file = form.get("image") as File | null;

  if (!title.trim() || !eventDate) {
    return NextResponse.json({ error: "Titel und Datum sind erforderlich." }, { status: 400 });
  }

  let imageUrl: string | undefined;
  if (file && file.size > 0) {
    const saved = await saveUploadedFile(file, "gallery", session.user.id);
    imageUrl = `/api/files/${encodeURIComponent(saved.storageKey)}`;
  }

  const entry = await prisma.timelineEntry.create({
    data: {
      title: title.trim(),
      description,
      eventDate: new Date(eventDate),
      imageUrl,
      authorId: session.user.id,
    },
    include: { author: { select: { name: true } } },
  });

  return NextResponse.json({ entry });
}
