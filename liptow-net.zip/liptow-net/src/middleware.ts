export { default } from "next-auth/middleware";

// Schützt die komplette Anwendung. Ohne gültige Sitzung wird jeder Aufruf
// automatisch auf /login umgeleitet. Ausgenommen sind nur die Login-Seite
// selbst, die NextAuth-API-Routen sowie statische Next.js-Assets.
export const config = {
  matcher: [
    "/((?!login|api/auth|_next/static|_next/image|favicon.ico|icons|manifest.json).*)",
  ],
};
