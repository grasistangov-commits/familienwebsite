import { promises as fs } from "fs";
import path from "path";
import { v4 as uuidv4 } from "uuid";

// Wurzelverzeichnis für alle lokal gespeicherten Dateien.
// In Docker wird dieser Pfad als Volume gemountet (siehe docker-compose.yml).
export const STORAGE_ROOT = process.env.STORAGE_ROOT || path.join(process.cwd(), "storage");

export function subDirFor(kind: "cloud" | "gallery" | "documents" | "avatars" | "chat") {
  return path.join(STORAGE_ROOT, kind);
}

export async function ensureDir(dirPath: string) {
  await fs.mkdir(dirPath, { recursive: true });
}

/**
 * Speichert eine hochgeladene Datei (aus einem Web-Request) lokal auf dem Server
 * und gibt den relativen Storage-Key sowie die öffentliche URL zurück.
 */
export async function saveUploadedFile(
  file: File,
  kind: "cloud" | "gallery" | "documents" | "avatars" | "chat",
  ownerId: string
) {
  const dir = path.join(subDirFor(kind), ownerId);
  await ensureDir(dir);

  const ext = path.extname(file.name) || "";
  const storageFileName = `${uuidv4()}${ext}`;
  const storageKey = path.join(kind, ownerId, storageFileName);
  const fullPath = path.join(STORAGE_ROOT, storageKey);

  const arrayBuffer = await file.arrayBuffer();
  await fs.writeFile(fullPath, Buffer.from(arrayBuffer));

  return {
    storageKey: storageKey.split(path.sep).join("/"),
    sizeBytes: BigInt(file.size),
    mimeType: file.type || "application/octet-stream",
    originalName: file.name,
  };
}

export async function deleteStoredFile(storageKey: string) {
  const fullPath = path.join(STORAGE_ROOT, storageKey);
  try {
    await fs.unlink(fullPath);
  } catch {
    // Datei war bereits nicht vorhanden – kein Problem.
  }
}

export function storageKeyToDownloadUrl(storageKey: string) {
  return `/api/files/${encodeURIComponent(storageKey)}`;
}
