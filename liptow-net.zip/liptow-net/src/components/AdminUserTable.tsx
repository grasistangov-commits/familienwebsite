"use client";

import { useState } from "react";
import { FiPlus, FiLock, FiUnlock, FiKey, FiTrash2, FiEdit2, FiX } from "react-icons/fi";
import { formatBytes } from "@/lib/utils";

type AdminUser = {
  id: string;
  name: string;
  email: string;
  role: "ADMIN" | "MEMBER";
  isLocked: boolean;
  mustChangePassword: boolean;
  storageUsedBytes: string;
  storageQuotaBytes: string;
};

export default function AdminUserTable({ initialUsers }: { initialUsers: AdminUser[] }) {
  const [users, setUsers] = useState(initialUsers);
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [newRole, setNewRole] = useState<"ADMIN" | "MEMBER">("MEMBER");
  const [credentialInfo, setCredentialInfo] = useState<{ email: string; password: string } | null>(
    null
  );
  const [editingUser, setEditingUser] = useState<AdminUser | null>(null);

  async function refresh() {
    const res = await fetch("/api/admin/users");
    if (res.ok) {
      const data = await res.json();
      setUsers(data.users);
    }
  }

  async function handleCreate() {
    const res = await fetch("/api/admin/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: newName, email: newEmail, role: newRole }),
    });
    const data = await res.json();
    if (!res.ok) {
      alert(data.error ?? "Fehler beim Anlegen.");
      return;
    }
    setCredentialInfo({ email: newEmail, password: data.tempPassword });
    setShowCreate(false);
    setNewName("");
    setNewEmail("");
    setNewRole("MEMBER");
    refresh();
  }

  async function handleToggleLock(id: string) {
    await fetch(`/api/admin/users/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "toggleLock" }),
    });
    refresh();
  }

  async function handleResetPassword(user: AdminUser) {
    if (!confirm(`Passwort von ${user.name} wirklich zurücksetzen?`)) return;
    const res = await fetch(`/api/admin/users/${user.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "resetPassword" }),
    });
    const data = await res.json();
    if (res.ok) setCredentialInfo({ email: user.email, password: data.tempPassword });
  }

  async function handleDelete(user: AdminUser) {
    if (!confirm(`Konto von ${user.name} unwiderruflich löschen?`)) return;
    const res = await fetch(`/api/admin/users/${user.id}`, { method: "DELETE" });
    const data = await res.json();
    if (!res.ok) {
      alert(data.error ?? "Löschen fehlgeschlagen.");
      return;
    }
    refresh();
  }

  async function handleSaveEdit() {
    if (!editingUser) return;
    await fetch(`/api/admin/users/${editingUser.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: editingUser.name,
        email: editingUser.email,
        role: editingUser.role,
      }),
    });
    setEditingUser(null);
    refresh();
  }

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h2 className="font-display text-lg font-semibold">Benutzerverwaltung</h2>
        <button onClick={() => setShowCreate(true)} className="btn-primary">
          <FiPlus size={15} />
          Neuer Benutzer
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="text-xs uppercase tracking-wide text-ink-900/50 dark:text-parchment-100/50">
              <th className="pb-3 font-medium">Name</th>
              <th className="pb-3 font-medium">E-Mail</th>
              <th className="pb-3 font-medium">Rolle</th>
              <th className="pb-3 font-medium">Speicher</th>
              <th className="pb-3 font-medium">Status</th>
              <th className="pb-3 font-medium text-right">Aktionen</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink-900/5 dark:divide-parchment-100/10">
            {users.map((u) => (
              <tr key={u.id}>
                <td className="py-3 font-medium">{u.name}</td>
                <td className="py-3 text-ink-900/60 dark:text-parchment-100/60">{u.email}</td>
                <td className="py-3">
                  <span
                    className={`rounded-full px-2 py-0.5 text-xs ${
                      u.role === "ADMIN"
                        ? "bg-ochre-500/15 text-ochre-600 dark:text-ochre-400"
                        : "bg-moss-600/10 text-moss-700 dark:text-moss-400"
                    }`}
                  >
                    {u.role === "ADMIN" ? "Administrator" : "Mitglied"}
                  </span>
                </td>
                <td className="py-3 text-xs text-ink-900/60 dark:text-parchment-100/60">
                  {formatBytes(Number(u.storageUsedBytes))} / {formatBytes(Number(u.storageQuotaBytes))}
                </td>
                <td className="py-3">
                  {u.isLocked ? (
                    <span className="text-xs text-red-700 dark:text-red-400">Gesperrt</span>
                  ) : (
                    <span className="text-xs text-moss-600 dark:text-ochre-400">Aktiv</span>
                  )}
                </td>
                <td className="py-3">
                  <div className="flex justify-end gap-1">
                    <button
                      title="Bearbeiten"
                      onClick={() => setEditingUser(u)}
                      className="rounded-lg p-1.5 hover:bg-ink-900/5 dark:hover:bg-parchment-100/5"
                    >
                      <FiEdit2 size={14} />
                    </button>
                    <button
                      title={u.isLocked ? "Entsperren" : "Sperren"}
                      onClick={() => handleToggleLock(u.id)}
                      className="rounded-lg p-1.5 hover:bg-ink-900/5 dark:hover:bg-parchment-100/5"
                    >
                      {u.isLocked ? <FiUnlock size={14} /> : <FiLock size={14} />}
                    </button>
                    <button
                      title="Passwort zurücksetzen"
                      onClick={() => handleResetPassword(u)}
                      className="rounded-lg p-1.5 hover:bg-ink-900/5 dark:hover:bg-parchment-100/5"
                    >
                      <FiKey size={14} />
                    </button>
                    <button
                      title="Löschen"
                      onClick={() => handleDelete(u)}
                      className="rounded-lg p-1.5 hover:bg-red-700/10"
                    >
                      <FiTrash2 size={14} className="text-red-700 dark:text-red-400" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showCreate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/40 p-4">
          <div className="card w-full max-w-sm p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">Neuen Benutzer anlegen</h3>
              <button onClick={() => setShowCreate(false)}>
                <FiX size={18} />
              </button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="label">Name</label>
                <input value={newName} onChange={(e) => setNewName(e.target.value)} className="input" />
              </div>
              <div>
                <label className="label">E-Mail</label>
                <input
                  type="email"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  className="input"
                />
              </div>
              <div>
                <label className="label">Rolle</label>
                <select
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value as "ADMIN" | "MEMBER")}
                  className="input"
                >
                  <option value="MEMBER">Mitglied</option>
                  <option value="ADMIN">Administrator</option>
                </select>
              </div>
              <button onClick={handleCreate} className="btn-primary w-full">
                Benutzer anlegen
              </button>
              <p className="text-xs text-ink-900/50 dark:text-parchment-100/50">
                Es wird automatisch ein Einmalpasswort erzeugt. Der Benutzer muss beim ersten
                Login ein eigenes Passwort festlegen.
              </p>
            </div>
          </div>
        </div>
      )}

      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/40 p-4">
          <div className="card w-full max-w-sm p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">Benutzer bearbeiten</h3>
              <button onClick={() => setEditingUser(null)}>
                <FiX size={18} />
              </button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="label">Name</label>
                <input
                  value={editingUser.name}
                  onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="label">E-Mail</label>
                <input
                  value={editingUser.email}
                  onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="label">Rolle</label>
                <select
                  value={editingUser.role}
                  onChange={(e) =>
                    setEditingUser({ ...editingUser, role: e.target.value as "ADMIN" | "MEMBER" })
                  }
                  className="input"
                >
                  <option value="MEMBER">Mitglied</option>
                  <option value="ADMIN">Administrator</option>
                </select>
              </div>
              <button onClick={handleSaveEdit} className="btn-primary w-full">
                Speichern
              </button>
            </div>
          </div>
        </div>
      )}

      {credentialInfo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/40 p-4">
          <div className="card w-full max-w-sm p-6 text-center">
            <h3 className="mb-2 font-display text-lg font-semibold">Zugangsdaten</h3>
            <p className="mb-4 text-sm text-ink-900/60 dark:text-parchment-100/60">
              Bitte diese Daten sicher an das Familienmitglied weitergeben.
            </p>
            <div className="mb-4 space-y-1 rounded-xl bg-ink-900/5 dark:bg-parchment-100/5 p-4 text-left text-sm">
              <p>
                <strong>E-Mail:</strong> {credentialInfo.email}
              </p>
              <p>
                <strong>Einmalpasswort:</strong> {credentialInfo.password}
              </p>
            </div>
            <button onClick={() => setCredentialInfo(null)} className="btn-primary w-full">
              Verstanden
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
