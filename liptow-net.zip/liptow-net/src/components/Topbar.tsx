"use client";

import { signOut } from "next-auth/react";
import { useState } from "react";
import { FiMenu, FiSun, FiMoon, FiLogOut } from "react-icons/fi";
import { useTheme } from "@/components/ThemeProvider";
import { initialsFromName } from "@/lib/utils";

export default function Topbar({
  name,
  avatarUrl,
  onMenuClick,
}: {
  name: string;
  avatarUrl?: string | null;
  onMenuClick: () => void;
}) {
  const { theme, toggle } = useTheme();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-20 flex items-center justify-between border-b border-ink-900/5 dark:border-parchment-100/10 bg-parchment-50/80 dark:bg-ink-950/80 px-5 py-3.5 backdrop-blur-md">
      <button
        onClick={onMenuClick}
        className="rounded-lg p-2 text-ink-900/70 dark:text-parchment-100/70 hover:bg-ink-900/5 dark:hover:bg-parchment-100/5 lg:hidden"
        aria-label="Menü öffnen"
      >
        <FiMenu size={20} />
      </button>

      <div className="hidden lg:block" />

      <div className="flex items-center gap-2">
        <button
          onClick={toggle}
          aria-label="Farbmodus wechseln"
          className="flex h-9 w-9 items-center justify-center rounded-full text-ink-900/70 dark:text-parchment-100/70 hover:bg-ink-900/5 dark:hover:bg-parchment-100/5"
        >
          {theme === "light" ? <FiMoon size={17} /> : <FiSun size={17} />}
        </button>

        <div className="relative">
          <button
            onClick={() => setMenuOpen((v) => !v)}
            className="flex items-center gap-2 rounded-full pl-1 pr-3 py-1 hover:bg-ink-900/5 dark:hover:bg-parchment-100/5"
          >
            {avatarUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={avatarUrl} alt={name} className="h-8 w-8 rounded-full object-cover" />
            ) : (
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-moss-600 text-xs font-semibold text-parchment-50">
                {initialsFromName(name)}
              </span>
            )}
            <span className="hidden text-sm font-medium sm:block">{name}</span>
          </button>

          {menuOpen && (
            <div className="absolute right-0 mt-2 w-44 overflow-hidden rounded-xl border border-ink-900/10 dark:border-parchment-100/10 bg-white dark:bg-ink-900 shadow-lg">
              <button
                onClick={() => signOut({ callbackUrl: "/login" })}
                className="flex w-full items-center gap-2 px-4 py-3 text-sm text-red-700 dark:text-red-400 hover:bg-red-700/5"
              >
                <FiLogOut size={15} />
                Abmelden
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
