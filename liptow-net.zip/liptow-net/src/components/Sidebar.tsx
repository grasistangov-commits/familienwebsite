"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  FiGrid,
  FiMessageCircle,
  FiHardDrive,
  FiImage,
  FiCalendar,
  FiGitBranch,
  FiBookOpen,
  FiFolder,
  FiUsers,
  FiCheckSquare,
  FiClock,
  FiUser,
  FiShield,
  FiX,
} from "react-icons/fi";

const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: FiGrid },
  { href: "/chat", label: "Familienchat", icon: FiMessageCircle },
  { href: "/cloud", label: "Familien-Cloud", icon: FiHardDrive },
  { href: "/gallery", label: "Fotogalerie", icon: FiImage },
  { href: "/kalender", label: "Kalender", icon: FiCalendar },
  { href: "/stammbaum", label: "Stammbaum", icon: FiGitBranch },
  { href: "/wiki", label: "Familienwiki", icon: FiBookOpen },
  { href: "/dokumente", label: "Dokumente", icon: FiFolder },
  { href: "/kontakte", label: "Kontakte", icon: FiUsers },
  { href: "/aufgaben", label: "Aufgaben", icon: FiCheckSquare },
  { href: "/timeline", label: "Erinnerungen", icon: FiClock },
];

export default function Sidebar({
  isAdmin,
  open,
  onClose,
}: {
  isAdmin: boolean;
  open: boolean;
  onClose: () => void;
}) {
  const pathname = usePathname();

  return (
    <>
      {open && (
        <div
          className="fixed inset-0 z-30 bg-ink-950/40 lg:hidden"
          onClick={onClose}
          aria-hidden
        />
      )}
      <aside
        className={`fixed z-40 flex h-full w-64 flex-col border-r border-ink-900/5 dark:border-parchment-100/10 bg-parchment-100/80 dark:bg-ink-900/80 backdrop-blur-md transition-transform lg:static lg:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between px-6 py-6">
          <Link href="/dashboard" className="font-display text-xl font-semibold">
            Liptow<span className="text-moss-600 dark:text-ochre-400">.net</span>
          </Link>
          <button
            className="rounded-md p-1 text-ink-900/50 dark:text-parchment-100/50 lg:hidden"
            onClick={onClose}
            aria-label="Menü schließen"
          >
            <FiX size={20} />
          </button>
        </div>

        <nav className="flex-1 space-y-0.5 overflow-y-auto px-3 pb-4 scrollbar-thin">
          {NAV.map(({ href, label, icon: Icon }) => {
            const active = pathname === href || pathname?.startsWith(href + "/");
            return (
              <Link
                key={href}
                href={href}
                onClick={onClose}
                className={`flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition ${
                  active
                    ? "bg-moss-600 text-parchment-50 shadow-sm"
                    : "text-ink-900/70 dark:text-parchment-100/70 hover:bg-ink-900/5 dark:hover:bg-parchment-100/5"
                }`}
              >
                <Icon size={17} />
                {label}
              </Link>
            );
          })}
        </nav>

        <div className="space-y-0.5 border-t border-ink-900/5 dark:border-parchment-100/10 px-3 py-3">
          <Link
            href="/profil"
            onClick={onClose}
            className={`flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition ${
              pathname === "/profil"
                ? "bg-moss-600 text-parchment-50"
                : "text-ink-900/70 dark:text-parchment-100/70 hover:bg-ink-900/5 dark:hover:bg-parchment-100/5"
            }`}
          >
            <FiUser size={17} />
            Mein Profil
          </Link>
          {isAdmin && (
            <Link
              href="/administration"
              onClick={onClose}
              className={`flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition ${
                pathname?.startsWith("/administration")
                  ? "bg-ochre-500 text-ink-950"
                  : "text-ochre-600 dark:text-ochre-400 hover:bg-ochre-500/10"
              }`}
            >
              <FiShield size={17} />
              Administration
            </Link>
          )}
        </div>
      </aside>
    </>
  );
}
