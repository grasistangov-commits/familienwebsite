import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const adminEmail = "admin@liptow.net";
  const adminPassword = "Administrator123";

  const existing = await prisma.user.findUnique({ where: { email: adminEmail } });
  if (existing) {
    console.log("Administrator existiert bereits, überspringe Seed.");
    return;
  }

  const passwordHash = await bcrypt.hash(adminPassword, 12);

  const admin = await prisma.user.create({
    data: {
      email: adminEmail,
      name: "Administrator",
      passwordHash,
      role: "ADMIN",
      mustChangePassword: false, // im Testsystem direkt einsatzbereit
    },
  });

  await prisma.activityLog.create({
    data: {
      action: "SYSTEM_SEED",
      detail: "Administrator-Konto wurde beim Setup automatisch angelegt.",
      userId: admin.id,
    },
  });

  console.log("Administrator-Konto erstellt:");
  console.log(`  E-Mail:    ${adminEmail}`);
  console.log(`  Passwort:  ${adminPassword}`);
  console.log("Bitte das Passwort nach dem ersten Login ändern.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
