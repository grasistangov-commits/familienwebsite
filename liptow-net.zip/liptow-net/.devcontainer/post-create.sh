#!/usr/bin/env bash
set -e

echo "Liptow.net – Einrichtung für GitHub Codespaces"
echo "================================================"

if [ ! -f .env ]; then
  echo "Erzeuge .env aus .env.example …"
  cp .env.example .env
fi

echo "Installiere npm-Abhängigkeiten …"
npm install

echo "Warte auf PostgreSQL …"
until pg_isready -h db -p 5432 -U "${POSTGRES_USER:-liptow}" >/dev/null 2>&1; do
  sleep 1
done

echo "Erzeuge Prisma-Client …"
npx prisma generate

echo "Wende Datenbankschema an …"
npx prisma db push

echo "Lege Administrator-Konto an (admin@liptow.net) …"
npm run db:seed

echo ""
echo "Fertig! Starte die Anwendung mit:"
echo "  npm run dev"
echo ""
echo "Login:"
echo "  E-Mail:    admin@liptow.net"
echo "  Passwort:  Administrator123"
